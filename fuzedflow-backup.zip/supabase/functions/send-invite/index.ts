import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
// 1. Import the Supabase client
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
// 2. Grab your Supabase environment variables
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

serve(async (req) => {
  console.log("1. Function triggered! Waking up...");

  try {
    const payload = await req.json()
    console.log("2. Payload received from database:", JSON.stringify(payload));
    
    const newInvite = payload.record

    if (!newInvite || !newInvite.email) {
      console.log("🚨 ERROR: No email found in the payload.");
      return new Response("No email found in payload", { status: 400 })
    }

    console.log(`3. Attempting to send email via Resend to: ${newInvite.email}`);

    // 3. Fetch the company data to use in the email template
    const { data: company, error: companyError } = await supabase
      .from('companies') // <-- Ensure this matches your actual table name
      .select('*')
      .eq('id', newInvite.company_id)
      .single()

    if (companyError) {
      console.log("🚨 ERROR fetching company:", companyError.message);
      // Optional: you could return early here, or let it fall back to an empty string
    }

    // Create the Sign Up URL
    const signupUrl = `https://app.fuzedflow.com/signup?email=${encodeURIComponent(newInvite.email)}`;

    // 4. Send the email via Resend
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'FuzedFlow <alerts@mail.fuzedflow.com>', 
        to: newInvite.email,
        subject: 'Invitation to join Fuzed Flow',
        html: `
          <div style="font-family: sans-serif; max-w-md; margin: 0 auto; padding: 20px; color: #0f172a;">
            <h2 style="color: #0f172a;">You're Invited!</h2>
            <p style="font-size: 16px; line-height: 1.5; color: #475569;">
              You have been invited to join the team at <strong>${company?.name || company?.company_name || 'your new team'}</strong> as a <strong>${newInvite.role}</strong>.
            </p>
            
            <div style="margin: 32px 0;">
              <a href="${signupUrl}" style="background-color: #f59e0b; color: #0f172a; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
                Accept Invitation
              </a>
            </div>

            <p style="font-size: 14px; color: #64748b; margin-top: 24px;">
              If the button doesn't work, copy and paste this link into your browser:<br/>
              <a href="${signupUrl}" style="color: #3b82f6; word-break: break-all;">${signupUrl}</a>
            </p>
          </div>
        `
      })
    })

    const data = await res.json()
    console.log("4. Resend API Response:", JSON.stringify(data));
    
    return new Response(JSON.stringify(data), { 
      headers: { "Content-Type": "application/json" },
      status: 200 
    })

  } catch (error) {
    console.error("🚨 CRITICAL ERROR:", error.message);
    return new Response(JSON.stringify({ error: error.message }), { status: 500 })
  }
})