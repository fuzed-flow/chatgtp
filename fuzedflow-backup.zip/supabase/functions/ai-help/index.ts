import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Configuration from "https://esm.sh/openai@4"
import OpenAIApi from "https://esm.sh/openai@4"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { query } = await req.json()
    
    if (!query) {
      return new Response(JSON.stringify({ error: 'No query provided' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    // 1. Initialize OpenAI and Supabase
    const openai = new OpenAIApi({ apiKey: Deno.env.get('OPENAI_API_KEY') })
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // 2. Turn the user's question into an embedding vector
    const embeddingResponse = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: query,
    })
    const embedding = embeddingResponse.data[0].embedding

    // 3. Search Supabase for the most relevant help docs
    const { data: documents, error: matchError } = await supabase.rpc('match_help_docs', {
      query_embedding: embedding,
      match_threshold: 0.75, // Adjust based on how strict you want matches to be
      match_count: 3         // Top 3 most relevant articles
    })

    if (matchError) throw matchError

    // 4. Combine the docs into a single context block
    const contextText = documents.map((doc: any) => doc.content).join('\n\n')

    // 5. Ask OpenAI to answer the question using ONLY the provided context
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini", // Fast, cheap, and smart enough for RAG
      messages: [
        {
          role: "system",
          content: `You are a helpful support assistant for our application. Answer the user's question using ONLY the context provided below. If the answer is not in the context, say "I'm sorry, I don't have information on that yet, please contact human support."\n\nContext:\n${contextText}`
        },
        {
          role: "user",
          content: query
        }
      ],
      temperature: 0.2, // Keep it factual, not creative
    })

    const reply = completion.choices[0].message.content

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })

  } catch (error) {
    console.error('Error:', error)
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})