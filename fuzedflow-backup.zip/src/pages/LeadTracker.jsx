import React, { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, Kanban, List as ListIcon, Phone, Mail, Calendar, DollarSign, GripVertical, Upload } from "lucide-react";
import StatusBadge from "../components/shared/StatusBadge";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import LeadFormDialog from "../components/leads/LeadFormDialog";
import DownloadButton from "../components/shared/DownloadButton";
import Papa from "papaparse";
import { toast } from "sonner";

const PIPELINE_STAGES = ["New", "Contacted", "Booked Visit", "Quoted", "Negotiation", "Won", "Lost"];

export default function LeadTracker() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;
  const queryClient = useQueryClient();

  const [viewMode, setViewMode] = useState("kanban"); // 'kanban' or 'list'
  const [searchTerm, setSearchTerm] = useState("");
  const [stageFilter, setStageFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const fileInputRef = useRef(null);

  // --- QUERIES ---
  const { data: leads = [], isLoading } = useQuery({
    queryKey: ["leads", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("company_id", companyId);
      if (error) throw error;
      return data || [];
    },
  });

  // --- MUTATIONS ---
  const createMutation = useMutation({
    mutationFn: async (data) => {
      const { error } = await supabase.from("leads").insert([{ ...data, company_id: companyId }]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads", companyId] });
      setDialogOpen(false);
      toast.success("Lead created successfully");
    },
  });

  const updateStageMutation = useMutation({
    mutationFn: async ({ id, pipeline_stage }) => {
      const { error } = await supabase.from("leads").update({ pipeline_stage }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads", companyId] });
    },
  });

  const importMutation = useMutation({
    mutationFn: async (parsedData) => {
      // Map CSV columns back to the database schema
      const leadsToInsert = parsedData.map(row => ({
        company_id: companyId,
        contact_name: row["Contact Name"] || row.contact_name,
        contact_email: row["Contact Email"] || row.contact_email,
        contact_phone: row["Contact Phone"] || row.contact_phone,
        pipeline_stage: row["Stage"] || row.pipeline_stage || "New",
        value_estimate: parseFloat(row["Value Estimate"] || row.value_estimate) || null,
        source: row["Source"] || row.source,
        description: row["Description"] || row.description
      }));

      const { error } = await supabase.from("leads").insert(leadsToInsert);
      if (error) throw error;
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ["leads", companyId] }); 
      toast.success("Leads imported successfully"); 
    },
    onError: (error) => {
      toast.error(`Import failed: ${error.message}`);
    }
  });

  // --- HANDLERS ---
  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.data && results.data.length > 0) {
          importMutation.mutate(results.data);
        } else {
          toast.error("No valid data found in CSV");
        }
        event.target.value = null; // Reset input to allow re-uploading the same file
      },
      error: (error) => {
        toast.error(`Failed to parse file: ${error.message}`);
      }
    });
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const { draggableId, destination } = result;
    const newStage = destination.droppableId;
    
    // Find the lead to check if stage actually changed
    const leadToMove = leads.find(l => l.id === draggableId);
    if (leadToMove && leadToMove.pipeline_stage !== newStage) {
      // Optimistic update
      queryClient.setQueryData(["leads", companyId], (old) => 
        old.map(l => l.id === draggableId ? { ...l, pipeline_stage: newStage } : l)
      );
      updateStageMutation.mutate({ id: draggableId, pipeline_stage: newStage });
    }
  };

  // --- FILTERING ---
  const filteredLeads = leads.filter(l => {
    const matchesSearch = 
      l.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.contact_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStage = stageFilter === "all" || l.pipeline_stage === stageFilter;
    return matchesSearch && matchesStage;
  });

  // --- COMPONENTS ---
  const LeadCard = ({ lead, isDraggable = false }) => {
    const content = (
      <Card className="p-4 bg-white hover:shadow-md transition-shadow border-slate-200 cursor-pointer group">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">{lead.contact_name}</h3>
          {isDraggable && <GripVertical className="h-4 w-4 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />}
        </div>
        {lead.value_estimate && (
          <div className="flex items-center gap-1 text-sm font-semibold text-emerald-600 mb-2">
            <DollarSign className="h-3.5 w-3.5" /> {Number(lead.value_estimate).toLocaleString()}
          </div>
        )}
        <div className="space-y-1">
          {lead.contact_email && (
             <div className="flex items-center gap-1.5 text-xs text-slate-600">
               <Mail className="h-3 w-3 shrink-0" /> <span className="truncate">{lead.contact_email}</span>
             </div>
          )}
          {lead.contact_phone && (
             <div className="flex items-center gap-1.5 text-xs text-slate-600">
               <Phone className="h-3 w-3 shrink-0" /> <span>{lead.contact_phone}</span>
             </div>
          )}
          {lead.next_follow_up_date && (
            <div className="flex items-center gap-1.5 text-xs text-amber-600 font-medium mt-2 pt-2 border-t border-slate-100">
              <Calendar className="h-3 w-3" /> Follow up: {format(new Date(lead.next_follow_up_date), "MMM d")}
            </div>
          )}
        </div>
      </Card>
    );

    return isDraggable ? content : <Link to={`/LeadDetail?id=${lead.id}`}>{content}</Link>;
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Lead Tracker</h1>
          <p className="text-sm text-slate-500">Manage incoming inquiries and sales pipeline</p>
        </div>
        
        {/* NEW: Action Buttons Group */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Hidden file input */}
          <input 
            type="file" 
            accept=".csv" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileUpload} 
          />
          
          <Button 
            variant="outline" 
            onClick={() => fileInputRef.current?.click()}
            disabled={importMutation.isPending}
            className="w-full sm:w-auto"
          >
            <Upload className="h-4 w-4 mr-2" /> 
            {importMutation.isPending ? "Importing..." : "Import"}
          </Button>

          <DownloadButton
            data={filteredLeads}
            filename="leads_export"
            columns={[
              { label: "Contact Name", key: "contact_name" },
              { label: "Contact Email", key: "contact_email" },
              { label: "Contact Phone", key: "contact_phone" },
              { label: "Stage", key: "pipeline_stage" },
              { label: "Value Estimate", key: "value_estimate" },
              { label: "Source", key: "source" },
              { label: "Description", key: "description" }
            ]}
          />

          <Button onClick={() => setDialogOpen(true)} className="bg-slate-900 hover:bg-slate-800 text-white shadow-sm w-full sm:w-auto">
            <Plus className="h-4 w-4 mr-2" /> New Lead
          </Button>
        </div>
      </div>

      {/* TOOLBAR */}
      <Card className="p-3 mb-6 bg-white border-slate-200/80 shadow-sm flex flex-col md:flex-row gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search leads..." 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="pl-9 bg-slate-50 border-slate-200 w-full"
          />
        </div>
        <div className="flex flex-wrap sm:flex-nowrap gap-2 w-full md:w-auto">
          {viewMode === "list" && (
            <Select value={stageFilter} onValueChange={setStageFilter}>
              <SelectTrigger className="w-full sm:w-[160px] bg-slate-50 border-slate-200">
                <Filter className="h-4 w-4 mr-2 text-slate-400 shrink-0" />
                <SelectValue placeholder="Filter Stage" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stages</SelectItem>
                {PIPELINE_STAGES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
          <div className="flex p-1 bg-slate-100 rounded-lg border border-slate-200 shrink-0 ml-auto sm:ml-0">
            <button 
              onClick={() => setViewMode("kanban")}
              className={`p-1.5 rounded-md transition-all ${viewMode === 'kanban' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
              title="Kanban View"
            >
              <Kanban className="h-4 w-4" />
            </button>
            <button 
              onClick={() => setViewMode("list")}
              className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
              title="List View"
            >
              <ListIcon className="h-4 w-4" />
            </button>
          </div>
        </div>
      </Card>

      {/* MAIN CONTENT AREA */}
      {isLoading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        </div>
      ) : (
        <div className="flex-1 overflow-hidden flex flex-col">
          {viewMode === "kanban" ? (
            /* ⚡ KANBAN BOARD */
            <DragDropContext onDragEnd={onDragEnd}>
              <div className="flex-1 overflow-x-hidden md:overflow-x-auto overflow-y-auto md:overflow-y-hidden pb-4 custom-scrollbar">
                <div className="flex flex-col md:flex-row gap-4 md:min-w-max h-full px-1">
                  {PIPELINE_STAGES.map(stage => {
                    const stageLeads = filteredLeads.filter(l => l.pipeline_stage === stage);
                    const stageTotal = stageLeads.reduce((sum, l) => sum + (Number(l.value_estimate) || 0), 0);
                    
                    return (
                      <div key={stage} className="w-full md:w-[300px] flex flex-col md:h-full max-h-[400px] md:max-h-[calc(100vh-250px)] bg-slate-100/50 rounded-xl border border-slate-200 overflow-hidden shrink-0">
                        <div className="p-3 border-b border-slate-200 bg-slate-50/80 flex justify-between items-center shrink-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-sm text-slate-800">{stage}</h3>
                            <span className="text-[10px] font-bold bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-full">{stageLeads.length}</span>
                          </div>
                          {stageTotal > 0 && <span className="text-xs font-semibold text-emerald-600">${stageTotal.toLocaleString()}</span>}
                        </div>
                        
                        <Droppable droppableId={stage}>
                          {(provided, snapshot) => (
                            <div 
                              ref={provided.innerRef} 
                              {...provided.droppableProps}
                              className={`flex-1 p-2 overflow-y-auto custom-scrollbar transition-colors ${snapshot.isDraggingOver ? 'bg-blue-50/50' : ''}`}
                            >
                              <div className="space-y-2 min-h-[150px]">
                                {stageLeads.map((lead, index) => (
                                  <Draggable key={lead.id} draggableId={lead.id} index={index}>
                                    {(provided, snapshot) => (
                                      <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        style={{ ...provided.draggableProps.style }}
                                        className={snapshot.isDragging ? 'opacity-90 shadow-xl ring-2 ring-blue-400 rounded-lg' : ''}
                                      >
                                        <Link to={`/LeadDetail?id=${lead.id}`} className="block">
                                          <LeadCard lead={lead} isDraggable={true} />
                                        </Link>
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            </div>
                          )}
                        </Droppable>
                      </div>
                    );
                  })}
                </div>
              </div>
            </DragDropContext>
          ) : (
            /* ⚡ CONDENSED LIST VIEW */
            <Card className="bg-white border-slate-200 shadow-sm overflow-hidden flex-1 flex flex-col">
              <div className="overflow-x-hidden md:overflow-x-auto flex-1">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-3 font-medium">Lead Details</th>
                      <th className="px-4 py-3 font-medium hidden sm:table-cell">Contact Info</th>
                      <th className="px-4 py-3 font-medium hidden md:table-cell">Est. Value</th>
                      <th className="px-4 py-3 font-medium hidden sm:table-cell">Status & Follow Up</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredLeads.map(lead => (
                      <tr key={lead.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer" onClick={() => window.location.href = `/LeadDetail?id=${lead.id}`}>
                        <td className="px-4 py-3 align-top">
                          <div className="flex justify-between items-start">
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors truncate">{lead.contact_name}</p>
                              <p className="text-xs text-slate-500 mb-1 sm:mb-0">{lead.source}</p>
                              
                              {/* Mobile-only condensed info */}
                              <div className="sm:hidden mt-2 space-y-1.5">
                                {lead.contact_email && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Mail className="h-3 w-3 shrink-0" /> <span className="truncate">{lead.contact_email}</span></div>}
                                {lead.contact_phone && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Phone className="h-3 w-3 shrink-0" /> <span>{lead.contact_phone}</span></div>}
                                {lead.next_follow_up_date && <div className="flex items-center gap-1.5 text-xs text-amber-600 font-medium pt-1"><Calendar className="h-3 w-3 shrink-0" /> {format(new Date(lead.next_follow_up_date), "MMM d")}</div>}
                              </div>
                            </div>
                            
                            {/* Mobile-only Stage Badge */}
                            <div className="sm:hidden shrink-0 ml-3">
                              <StatusBadge status={lead.pipeline_stage} />
                            </div>
                          </div>
                        </td>
                        
                        <td className="px-4 py-3 hidden sm:table-cell space-y-1.5 align-top">
                          {lead.contact_email && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Mail className="h-3 w-3 shrink-0" /> <span className="truncate max-w-[180px] lg:max-w-none">{lead.contact_email}</span></div>}
                          {lead.contact_phone && <div className="flex items-center gap-1.5 text-xs text-slate-600"><Phone className="h-3 w-3 shrink-0" /> {lead.contact_phone}</div>}
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell align-top font-medium text-emerald-600">
                          {lead.value_estimate ? `$${Number(lead.value_estimate).toLocaleString()}` : "—"}
                        </td>
                        <td className="px-4 py-3 hidden sm:table-cell align-top">
                          <div className="space-y-1.5">
                            <StatusBadge status={lead.pipeline_stage} />
                            <div className="text-xs text-slate-500 font-medium">
                              {lead.next_follow_up_date ? `Follow up: ${format(new Date(lead.next_follow_up_date), "MMM d")}` : "—"}
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredLeads.length === 0 && (
                      <tr><td colSpan="4" className="px-4 py-8 text-center text-slate-500">No leads found matching your criteria.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </div>
      )}

      <LeadFormDialog 
        open={dialogOpen} 
        onOpenChange={setDialogOpen} 
        users={users} 
        onSave={(data) => createMutation.mutate(data)} 
      />
      
    </div>
  );
}