import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { 
  ListChecks, Search, Calendar, AlertCircle, ChevronLeft, ChevronRight, 
  Plus, Edit2, Trash2, Flame, CalendarPlus, MoreVertical 
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { format, parseISO, isValid } from "date-fns";

import CreateTaskDialog from "../components/tasks/CreateTaskDialog"; 

const STATUSES = ["To Do", "Doing", "Blocked", "Done", "Pending", "Active", "Under Review", "Completed"];
const PRIORITIES = ["Low", "Medium", "High", "Urgent"];
const ITEMS_PER_PAGE = 15;

const safeParseDate = (dateString) => {
  if (!dateString) return null;
  const parsed = parseISO(dateString);
  return isValid(parsed) ? parsed : null;
};

const normalizeStatus = (dbStatus) => {
  const s = dbStatus?.toLowerCase() || "";
  if (s.includes("to do") || s === "pending") return "Pending";
  if (s.includes("progress") || s.includes("active") || s.includes("doing")) return "Active";
  if (s.includes("review") || s.includes("blocked")) return "Under Review";
  if (s.includes("done") || s.includes("complete")) return "Completed";
  return "Pending";
};

const getPriorityColor = (priority) => {
  switch (priority?.toLowerCase()) {
    case "urgent": return "text-white bg-red-600 border-red-700 shadow-md ring-2 ring-red-200 animate-pulse";
    case "high": return "text-red-800 bg-red-100 border-red-300";
    case "medium": return "text-amber-800 bg-amber-100 border-amber-300";
    case "low": return "text-green-800 bg-green-100 border-green-300";
    default: return "text-slate-600 bg-slate-100 border-slate-200";
  }
};

const getClientName = (c) => {
  if (!c) return "Unknown Client";
  if (c.name && c.name.trim() !== "") return c.name;
  const fullName = [c.first_name, c.surname].filter(Boolean).join(" ");
  if (fullName && fullName.trim() !== "") return fullName;
  if (c.primary_contact_name && c.primary_contact_name.trim() !== "") return c.primary_contact_name;
  return "Unnamed Client";
};

const getProjectName = (p) => {
  if (!p) return "Unknown Project";
  if (p.name && p.name.trim() !== "") return p.name;
  if (p.project_number) return `Project #${p.project_number}`;
  return "Unnamed Project";
};

export default function Tasks() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;
  console.log("My Company ID is:", companyId);
  const qc = useQueryClient();

  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all"); 
  const [currentPage, setCurrentPage] = useState(1);

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [viewingTask, setViewingTask] = useState(null);

  const [editForm, setEditForm] = useState({
    id: null,
    title: "",
    description: "",
    client_id: "none",
    project_id: "none",
    status: "Pending",
    priority: "Medium",
    due_date_target: "",
    estimated_hours: "",
    assigned_to: "none"
  });

  // --- QUERIES ---
  const { data: companyData } = useQuery({
    queryKey: ["company", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("name").eq("id", companyId).single();
      return data || { name: "Company" };
    }
  });

  const { data: rawProjects = [] } = useQuery({ 
    queryKey: ["projects", companyId], 
    enabled: !!companyId,
    queryFn: async () => {
      const { data } = await supabase.from("projects").select("id, name, project_number").eq("company_id", companyId);
      return data || [];
    } 
  });

  const { data: rawClients = [] } = useQuery({ 
    queryKey: ["clients", companyId], 
    enabled: !!companyId,
    queryFn: async () => {
      // FIX: Explicitly selecting basic text columns to prevent query from failing silently
      const { data } = await supabase.from("clients").select("id, name, first_name, surname, primary_contact_name").eq("company_id", companyId);
      return data || [];
    } 
  });

  const { data: rawUsers = [] } = useQuery({
    queryKey: ["company_users", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, full_name").eq("company_id", companyId);
      return data || [];
    }
  });

  const { data: allTasks = [], isLoading } = useQuery({ 
    queryKey: ["project_tasks", companyId], 
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("project_tasks").select("*").eq("company_id", companyId).order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    } 
  });

  // MEMOIZED ARRAYS
  const projects = useMemo(() => Array.from(new Map(rawProjects.filter(p => p?.id).map(p => [p.id, p])).values()), [rawProjects]);
  const clients = useMemo(() => Array.from(new Map(rawClients.filter(c => c?.id).map(c => [c.id, c])).values()), [rawClients]);
  const users = useMemo(() => rawUsers.filter(u => u?.id), [rawUsers]);

  // MAPS
  const projectMap = useMemo(() => Object.fromEntries(projects.map(p => [p.id, getProjectName(p)])), [projects]);
  const clientMap = useMemo(() => Object.fromEntries(clients.map(c => [c.id, getClientName(c)])), [clients]);
  const userMap = useMemo(() => Object.fromEntries(users.map(u => [u.id, u.full_name])), [users]);

  // FIX: Safety guards to ensure Radix UI doesn't crash if an ID doesn't exist.
  const safeEditClientId = clients.some(c => String(c.id) === String(editForm.client_id)) ? String(editForm.client_id) : "none";
  const safeEditProjectId = projects.some(p => String(p.id) === String(editForm.project_id)) ? String(editForm.project_id) : "none";
  const safeEditAssignedTo = users.some(u => String(u.id) === String(editForm.assigned_to)) ? String(editForm.assigned_to) : "none";
  const safePriority = PRIORITIES.includes(editForm.priority) ? editForm.priority : "Medium";
  const safeStatus = STATUSES.includes(editForm.status) ? editForm.status : "To Do";

  // --- MUTATIONS ---
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }) => await supabase.from("project_tasks").update({ status }).eq("id", id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["project_tasks"] }); toast.success("Status updated"); }
  });

  const handleCreateSubmit = useMutation({
    mutationFn: async (payload) => {
      const assignedToVal = payload.assigned_to && payload.assigned_to !== "none" ? [payload.assigned_to] : null;
      const taskPayload = {
        company_id: companyId,
        title: payload.title,
        description: payload.description || null,
        project_id: (!payload.project_id || payload.project_id === "none") ? null : payload.project_id,
        client_id: (!payload.client_id || payload.client_id === "none") ? null : payload.client_id,
        status: payload.status || "To Do",
        priority: payload.priority || "Medium",
        due_date_target: payload.due_date || payload.due_date_target || null,
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: assignedToVal 
      };
      const { error } = await supabase.from("project_tasks").insert([taskPayload]);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["project_tasks"] }); setCreateDialogOpen(false); toast.success("Task created!"); },
    onError: (err) => toast.error(`Error: ${err.message}`)
  });

  const handleEditSubmit = useMutation({
    mutationFn: async (payload) => {
      const assignedToVal = payload.assigned_to && payload.assigned_to !== "none" ? [payload.assigned_to] : null;
      const taskPayload = {
        title: payload.title,
        description: payload.description || null,
        project_id: (!payload.project_id || payload.project_id === "none") ? null : payload.project_id,
        client_id: (!payload.client_id || payload.client_id === "none") ? null : payload.client_id,
        status: payload.status || "To Do",
        priority: payload.priority || "Medium",
        due_date_target: payload.due_date_target || null,
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: assignedToVal 
      };
      const { error } = await supabase.from("project_tasks").update(taskPayload).eq("id", payload.id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["project_tasks"] }); setEditDialogOpen(false); toast.success("Task updated!"); },
    onError: (err) => toast.error(`Error: ${err.message}`)
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id) => await supabase.from("project_tasks").delete().eq("id", id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["project_tasks"] }); toast.success("Task deleted."); }
  });

  // --- HANDLERS ---
  const openEditModal = (task) => {
    // FIX: Safely parse values. If they are null/undefined, force them to become "none"
    const assigneeVal = Array.isArray(task.assigned_to) && task.assigned_to.length > 0 ? task.assigned_to[0] : task.assigned_to;
    
    setEditForm({
      id: task.id,
      title: task.title || "",
      description: task.description || "",
      project_id: task.project_id ? String(task.project_id) : "none",
      client_id: task.client_id ? String(task.client_id) : "none",
      status: task.status || "Pending",
      priority: task.priority || "Medium",
      due_date_target: task.due_date_target || "",
      estimated_hours: task.estimated_hours || "",
      assigned_to: (assigneeVal && typeof assigneeVal === "string") ? assigneeVal : "none"
    });
    setEditDialogOpen(true);
  };

  const handleAddToCalendar = (task) => {
    if (!task.due_date_target) return toast.error("Please set a target date on this task first!");
    const cleanDate = task.due_date_target.replace(/-/g, "");
    const projectName = projectMap[task.project_id] || "No Project";
    const title = encodeURIComponent(`Task: ${task.title}`);
    const desc = encodeURIComponent(`${task.description || "No extra details."}\n\nProject: ${projectName}`);
    window.open(`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${cleanDate}/${cleanDate}&details=${desc}`, "_blank");
  };

  // --- FILTERING ---
  const filteredTasks = allTasks.filter(t => {
    const matchSearch = !search || t.title?.toLowerCase().includes(search.toLowerCase());
    const taskStatus = normalizeStatus(t.status);
    let matchStatus = filterStatus === "all" ? true : filterStatus === "unfinished" ? taskStatus !== "Completed" : taskStatus === filterStatus;
    return matchSearch && matchStatus;
  }).sort((a, b) => {
    const aComp = normalizeStatus(a.status) === "Completed";
    const bComp = normalizeStatus(b.status) === "Completed";
    const aDate = safeParseDate(a.due_date_target);
    const bDate = safeParseDate(b.due_date_target);
    const aOverdue = aDate && aDate < new Date() && !aComp;
    const bOverdue = bDate && bDate < new Date() && !bComp;

    if (!aComp && a.priority === "Urgent" && (bComp || b.priority !== "Urgent")) return -1;
    if (!bComp && b.priority === "Urgent" && (aComp || a.priority !== "Urgent")) return 1;
    if (aOverdue && !bOverdue) return -1;
    if (bOverdue && !aOverdue) return 1;
    return 0;
  });

  const totalPages = Math.ceil(filteredTasks.length / ITEMS_PER_PAGE);
  const indexOfLastItem = currentPage * ITEMS_PER_PAGE;
  const indexOfFirstItem = indexOfLastItem - ITEMS_PER_PAGE;
  const currentItems = filteredTasks.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-4 md:space-y-6">
      
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-end">
        <div>
          <h1 className="text-xl md:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ListChecks className="h-6 w-6 md:h-7 md:w-7 text-blue-600" /> {companyData?.name || "Company"} Action Items
          </h1>
          <p className="text-xs md:text-sm font-bold text-slate-500 mt-1 uppercase tracking-wider">{filteredTasks.length} matching tasks across all projects</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)} className="bg-amber-500 hover:bg-amber-600 text-white font-bold shadow-md shrink-0 w-full sm:w-auto">
          <Plus className="h-4 w-4 mr-2" /> New Task
        </Button>
      </div>

      {/* FILTER BAR */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search task descriptions..." 
            value={search} 
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }} 
            className="pl-9 w-full bg-white font-medium h-10" 
          />
        </div>
        <div className="w-full sm:w-[200px]">
          <Select value={filterStatus} onValueChange={(val) => { setFilterStatus(val); setCurrentPage(1); }}>
            <SelectTrigger className="w-full bg-white font-bold h-10"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Every Status</SelectItem>
              <SelectItem value="unfinished" className="font-bold text-blue-700">All Unfinished Tasks</SelectItem>
              <div className="border-t border-slate-100 my-1"></div>
              {["Pending", "Active", "Under Review", "Completed"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* TASKS LIST */}
      <Card className="overflow-hidden border-slate-200 shadow-sm bg-slate-50 md:bg-white flex flex-col">
        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <div className="h-8 w-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="text-center py-16 px-4 bg-white">
            <ListChecks className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-700">No tasks found</h3>
            <p className="text-sm text-slate-500 mt-1">Check your search spelling or change your filters.</p>
          </div>
        ) : (
          <div className="w-full flex-1 md:pb-4">
            
            {/* Desktop Table View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm text-left whitespace-nowrap border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-black text-slate-500 tracking-wider">
                  <tr>
                    <th className="px-4 md:px-6 py-3 md:py-4">Action Item</th>
                    <th className="px-4 md:px-6 py-3 md:py-4">Client/Project</th>
                    <th className="px-4 md:px-6 py-3 md:py-4">Status</th>
                    <th className="px-4 md:px-6 py-3 md:py-4">Priority</th>
                    <th className="px-4 md:px-6 py-3 md:py-4">Target Date</th>
                    <th className="px-4 md:px-6 py-3 md:py-4">Assigned To</th>
                    <th className="px-4 md:px-6 py-3 md:py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {currentItems.map(task => {
                    const dueDateObj = safeParseDate(task.due_date_target);
                    const isCompleted = normalizeStatus(task.status) === "Completed";
                    const isOverdue = dueDateObj && dueDateObj < new Date() && !isCompleted;
                    const isUrgent = task.priority?.toLowerCase() === "urgent" && !isCompleted;
                    const isHigh = task.priority?.toLowerCase() === "high" && !isCompleted;

                    let assignees = [];
                    if (Array.isArray(task.assigned_to)) {
                      assignees = task.assigned_to.map(id => userMap[id]).filter(Boolean);
                    } else if (task.assigned_to && userMap[task.assigned_to]) {
                      assignees = [userMap[task.assigned_to]];
                    }

                    let rowClass = "transition-all hover:bg-slate-50 relative group";
                    if (isCompleted) rowClass = "transition-all bg-slate-50 opacity-60 relative";
                    else if (isOverdue) rowClass = "transition-all bg-rose-50/70 hover:bg-rose-100/80 relative group";
                    else if (isUrgent) rowClass = "transition-all bg-red-50 hover:bg-red-100 relative group";
                    else if (isHigh) rowClass = "transition-all bg-orange-50/30 hover:bg-orange-50 relative group";

                    return (
                      <tr key={task.id} className={rowClass}>
                        <td className="px-4 md:px-6 py-3 md:py-4 relative">
                          {!isCompleted && (isOverdue || isUrgent) && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-red-600"></div>}
                          {!isCompleted && isHigh && !isOverdue && <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-400"></div>}

                          <div className="flex items-start gap-2 pl-1">
                            {!isCompleted && isUrgent && <Flame className="h-4 w-4 text-red-600 fill-red-600 animate-bounce shrink-0 mt-0.5" />}
                            <button type="button" className="text-left cursor-pointer group/text focus:outline-none" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setViewingTask(task); }}>
                              <p className={`font-bold truncate max-w-[200px] md:max-w-[280px] group-hover/text:text-blue-600 group-hover/text:underline transition-colors ${isCompleted ? 'text-slate-500 line-through' : (isUrgent || isOverdue) ? 'text-red-900 font-extrabold' : 'text-slate-900'}`}>{task.title}</p>
                              {task.description && <p className={`text-[10px] mt-0.5 truncate max-w-[200px] md:max-w-[280px] group-hover/text:text-blue-600 transition-colors ${(isUrgent || isOverdue) ? 'text-red-700/70 font-semibold' : 'text-slate-500'}`}>{task.description}</p>}
                            </button>
                          </div>
                        </td>
                        
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <div className="flex flex-col gap-1 items-start">
                            {task.client_id && <Badge variant="outline" className="text-[10px] uppercase tracking-wider bg-slate-100 text-slate-700 border-slate-300">{clientMap[task.client_id] || "Unknown Client"}</Badge>}
                            {task.project_id ? (
                              <Badge variant="outline" className={`text-[10px] uppercase tracking-wider border-slate-200 ${(isUrgent || isOverdue) ? 'bg-white/70 text-red-800 font-bold border-red-200' : 'bg-white'}`}>
                                {projectMap[task.project_id] || "Unknown Project"}
                              </Badge>
                            ) : (!task.client_id && <span className="text-xs text-slate-400 italic">—</span>)}
                          </div>
                        </td>
                        
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <Select value={normalizeStatus(task.status)} onValueChange={v => updateStatusMutation.mutate({ id: task.id, status: v })}>
                            <SelectTrigger className={`w-[130px] h-8 text-xs font-bold ${isCompleted ? 'bg-green-50 text-green-700 border-green-200' : (isUrgent || isOverdue) ? 'bg-white border-red-300 text-red-900 shadow-sm' : 'bg-white'}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {["Pending", "Active", "Under Review", "Completed"].map(s => <SelectItem key={s} value={s} className="text-xs font-bold">{s}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </td>
                        
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          {task.priority ? <Badge variant="outline" className={`text-[10px] uppercase tracking-wider font-black ${getPriorityColor(task.priority)}`}>{task.priority}</Badge> : <span className="text-xs text-slate-400">—</span>}
                        </td>
                        
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          {dueDateObj ? (
                            isOverdue ? (
                              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-100 text-red-700 border border-red-300 text-xs font-black shadow-sm ring-2 ring-red-100/50 animate-pulse">
                                <AlertCircle className="h-3.5 w-3.5 stroke-[3]" />OVERDUE: {format(dueDateObj, "MMM d")}
                              </div>
                            ) : (
                              <div className={`flex items-center gap-1.5 text-xs font-bold ${isUrgent ? 'text-red-800' : 'text-slate-600'}`}>
                                <Calendar className={`h-3.5 w-3.5 ${isUrgent ? 'text-red-500' : 'text-slate-400'}`} />{format(dueDateObj, "MMM d, yyyy")}
                              </div>
                            )
                          ) : <span className="text-xs text-slate-400 italic">No date</span>}
                        </td>
                        
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          {assignees.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                              {assignees.map((name, i) => (
                                <div key={i} className={`inline-block h-7 w-7 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-black title ${(isUrgent || isOverdue) ? 'bg-red-200 text-red-900' : 'bg-blue-100 text-blue-800'}`} title={name}>{name.charAt(0).toUpperCase()}</div>
                              ))}
                            </div>
                          ) : <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${(isUrgent || isOverdue) ? 'text-red-600 bg-red-100' : 'text-slate-400 bg-slate-100'}`}>Unassigned</span>}
                        </td>

                        <td className="px-4 md:px-6 py-3 md:py-4 text-right">
                          <div className="flex items-center justify-end gap-1 opacity-50 group-hover:opacity-100 transition-opacity">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0 text-slate-400 hover:text-slate-600 transition-colors">
                                  <span className="sr-only">Open menu</span><MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-40">
                                <DropdownMenuItem onClick={() => handleAddToCalendar(task)} className="cursor-pointer text-emerald-600 font-medium"><CalendarPlus className="h-4 w-4 mr-2" /> Calendar</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => openEditModal(task)} className="cursor-pointer text-blue-600 font-medium"><Edit2 className="h-4 w-4 mr-2" /> Edit Task</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => { if(window.confirm("Delete this task?")) deleteTaskMutation.mutate(task.id); }} className="cursor-pointer text-red-600 focus:text-red-600 font-medium"><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden flex flex-col gap-3 p-3">
              {currentItems.map(task => {
                const dueDateObj = safeParseDate(task.due_date_target);
                const isCompleted = normalizeStatus(task.status) === "Completed";
                const isOverdue = dueDateObj && dueDateObj < new Date() && !isCompleted;
                const isUrgent = task.priority?.toLowerCase() === "urgent" && !isCompleted;
                const isHigh = task.priority?.toLowerCase() === "high" && !isCompleted;

                let cardClass = "bg-white p-4 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden";
                if (isCompleted) cardClass = "bg-slate-50 p-4 rounded-xl border border-slate-200 opacity-70 relative overflow-hidden";
                else if (isOverdue) cardClass = "bg-rose-50 p-4 rounded-xl border border-rose-200 shadow-sm relative overflow-hidden";
                else if (isUrgent) cardClass = "bg-red-50 p-4 rounded-xl border border-red-200 shadow-sm relative overflow-hidden";
                else if (isHigh) cardClass = "bg-orange-50/50 p-4 rounded-xl border border-orange-200 shadow-sm relative overflow-hidden";

                return (
                  <div key={task.id} className={cardClass}>
                    {!isCompleted && (isOverdue || isUrgent) && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-red-600"></div>}
                    {!isCompleted && isHigh && !isOverdue && <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-400"></div>}

                    <div className="pl-2">
                      <div className="flex justify-between items-start mb-2">
                        <button type="button" className="flex flex-col items-start pr-2 cursor-pointer group/title focus:outline-none w-full text-left" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setViewingTask(task); }}>
                          <div className="flex items-center gap-2">
                            {!isCompleted && isUrgent && <Flame className="h-4 w-4 text-red-600 fill-red-600 animate-bounce shrink-0" />}
                            <h3 className={`font-bold text-base line-clamp-2 group-hover/title:text-blue-600 group-hover/title:underline ${isCompleted ? 'text-slate-500 line-through' : (isUrgent || isOverdue) ? 'text-red-900 font-extrabold' : 'text-slate-900'}`}>{task.title}</h3>
                          </div>
                          {task.description && <p className={`text-xs mt-1 line-clamp-2 group-hover/title:text-blue-600 ${(isUrgent || isOverdue) ? 'text-red-700/80 font-medium' : 'text-slate-500'}`}>{task.description}</p>}
                        </button>
                        
                        <div className="flex items-center gap-1 shrink-0">
                          <Button variant="ghost" size="icon" onClick={() => handleAddToCalendar(task)} className="h-7 w-7 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50"><CalendarPlus className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openEditModal(task)} className="h-7 w-7 text-slate-400 hover:text-blue-600 hover:bg-blue-50"><Edit2 className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => { if(window.confirm("Delete this task?")) deleteTaskMutation.mutate(task.id); }} className="h-7 w-7 text-slate-400 hover:text-red-600 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 mb-3 mt-1">
                        {task.client_id && <Badge variant="outline" className="text-[10px] uppercase tracking-wider bg-slate-100 text-slate-700 border-slate-300">{clientMap[task.client_id] || "Client"}</Badge>}
                        {task.project_id && <Badge variant="outline" className={`text-[10px] uppercase tracking-wider ${(isUrgent || isOverdue) ? 'bg-white/70 text-red-800 border-red-200' : 'bg-white'}`}>{projectMap[task.project_id] || "Project"}</Badge>}
                        {task.priority && <Badge variant="outline" className={`text-[10px] uppercase tracking-wider font-black ${getPriorityColor(task.priority)}`}>{task.priority}</Badge>}
                      </div>

                      <div className="flex items-center justify-between border-t border-slate-100/50 pt-3">
                        <Select value={normalizeStatus(task.status)} onValueChange={v => updateStatusMutation.mutate({ id: task.id, status: v })}>
                          <SelectTrigger className={`w-[110px] h-8 text-xs font-bold ${isCompleted ? 'bg-green-50 text-green-700 border-green-200' : (isUrgent || isOverdue) ? 'bg-white border-red-300 text-red-900' : 'bg-white'}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {["Pending", "Active", "Under Review", "Completed"].map(s => <SelectItem key={s} value={s} className="text-xs font-bold">{s}</SelectItem>)}
                          </SelectContent>
                        </Select>

                        {dueDateObj ? (
                          isOverdue ? (
                            <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-red-100 text-red-700 border border-red-300 text-[10px] font-black animate-pulse"><AlertCircle className="h-3 w-3 stroke-[3]" />DUE {format(dueDateObj, "MMM d")}</div>
                          ) : (
                            <div className={`flex items-center gap-1.5 text-xs font-bold ${isUrgent ? 'text-red-800' : 'text-slate-600'}`}><Calendar className={`h-3.5 w-3.5 ${isUrgent ? 'text-red-500' : 'text-slate-400'}`} />{format(dueDateObj, "MMM d, yyyy")}</div>
                          )
                        ) : <span className="text-[10px] text-slate-400 italic">No date</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* PAGINATION */}
        {!isLoading && filteredTasks.length > 0 && (
          <div className="border-t border-slate-200 bg-white md:bg-slate-50 px-4 md:px-6 py-3 flex items-center justify-between mt-auto">
            <span className="text-xs font-medium text-slate-500 hidden sm:inline-block">
              Showing <span className="font-bold text-slate-900">{indexOfFirstItem + 1}</span> to <span className="font-bold text-slate-900">{Math.min(indexOfLastItem, filteredTasks.length)}</span> of <span className="font-bold text-slate-900">{filteredTasks.length}</span>
            </span>
            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
              <Button variant="outline" size="sm" className="h-8 bg-white font-bold" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}><ChevronLeft className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Previous</span></Button>
              <span className="text-xs font-bold text-slate-600 sm:hidden">Page {currentPage} of {totalPages || 1}</span>
              <Button variant="outline" size="sm" className="h-8 bg-white font-bold" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages || totalPages === 0}><span className="hidden sm:inline">Next</span><ChevronRight className="h-4 w-4 sm:ml-1" /></Button>
            </div>
          </div>
        )}
      </Card>

      {/* VIEW FULL DETAILS DIALOG */}
      <Dialog open={!!viewingTask} onOpenChange={(val) => !val && setViewingTask(null)}>
        <DialogContent className="sm:max-w-lg w-[95vw] rounded-xl p-4 sm:p-6" aria-describedby={undefined}>
          <DialogHeader><DialogTitle className="text-xl font-black text-slate-900 leading-tight">{viewingTask?.title}</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-2">
            <div>
              <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5 block">Full Description</Label>
              <div className="text-sm font-medium text-slate-700 whitespace-pre-wrap bg-slate-50/80 p-4 rounded-xl border border-slate-200 min-h-[120px] max-h-[400px] overflow-y-auto custom-scrollbar">
                {viewingTask?.description || <span className="italic text-slate-400">No description provided.</span>}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row justify-end gap-2 pt-2 border-t border-slate-100 mt-2">
              <Button variant="outline" className="w-full sm:w-auto font-bold" onClick={() => setViewingTask(null)}>Close</Button>
              <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold" onClick={() => { openEditModal(viewingTask); setViewingTask(null); }}>
                <Edit2 className="h-4 w-4 mr-2" /> Edit Task
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* IMPORTED CREATE TASK DIALOG */}
      <CreateTaskDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        clients={clients}
        projects={projects}
        users={users}
        isLoading={handleCreateSubmit.isPending}
        onSubmit={(payload) => handleCreateSubmit.mutate(payload)}
      />

      {/* INLINE EDIT TASK DIALOG */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-lg w-[95vw] max-h-[90vh] overflow-y-auto rounded-xl p-4 sm:p-6 bg-white" aria-describedby={undefined}>
          <DialogHeader><DialogTitle className="text-xl font-black text-slate-900">Edit Task</DialogTitle></DialogHeader>
          
          <form onSubmit={(e) => { e.preventDefault(); handleEditSubmit.mutate(editForm); }} className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Task Title *</Label>
              <Input value={editForm.title} onChange={e => setEditForm({...editForm, title: e.target.value})} className="mt-1 font-bold border-slate-200" required />
            </div>
            
            <div className="space-y-2">
              <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Description</Label>
              <Textarea value={editForm.description} onChange={e => setEditForm({...editForm, description: e.target.value})} className="mt-1 flex min-h-[80px] w-full resize-none font-medium border-slate-200" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Client</Label>
                <Select value={safeEditClientId} onValueChange={v => setEditForm({...editForm, client_id: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select Client" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Client</SelectItem>
                    {clients.map((c) => (
                      <SelectItem key={String(c.id)} value={String(c.id)}>
                        {getClientName(c)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Project</Label>
                <Select value={safeEditProjectId} onValueChange={v => setEditForm({...editForm, project_id: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select Project" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Project</SelectItem>
                    {projects.map((p) => (
                      <SelectItem key={String(p.id)} value={String(p.id)}>
                        {getProjectName(p)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Assignee</Label>
                <Select value={safeEditAssignedTo} onValueChange={v => setEditForm({...editForm, assigned_to: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Unassigned" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Unassigned</SelectItem>
                    {users.map((u) => (
                      <SelectItem key={String(u.id)} value={String(u.id)}>
                        {u.full_name || "Unknown User"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Priority</Label>
                <Select value={safePriority} onValueChange={v => setEditForm({...editForm, priority: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Status</Label>
                <Select value={safeStatus} onValueChange={v => setEditForm({...editForm, status: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Target Date</Label>
                <Input type="date" value={editForm.due_date_target || ""} onChange={e => setEditForm({...editForm, due_date_target: e.target.value})} className="font-medium border-slate-200 text-sm block w-full" />
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Est. Hours</Label>
                <Input type="number" min="0" step="0.5" value={editForm.estimated_hours || ""} onChange={(e) => setEditForm({ ...editForm, estimated_hours: e.target.value })} className="font-medium border-slate-200 text-sm" />
              </div>
            </div>

            <DialogFooter className="pt-4 border-t border-slate-100 flex-col sm:flex-row gap-2 sm:gap-0 mt-2">
              <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)} className="w-full sm:w-auto font-bold border-slate-300 order-2 sm:order-1">Cancel</Button>
              <Button type="submit" disabled={handleEditSubmit.isPending} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md order-1 sm:order-2">
                {handleEditSubmit.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}