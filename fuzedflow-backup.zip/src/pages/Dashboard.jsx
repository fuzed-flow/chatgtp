import React, { useState, useEffect } from "react";
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import {
  Target, FileText, FolderKanban, Receipt, CalendarDays,
  Plus, ArrowRight, Clock, AlertTriangle, TrendingUp, MessageSquare, 
  X, Users, Play, CheckSquare, ChevronDown, ChevronUp, Phone, Mail, MapPin, DollarSign, LayoutTemplate, Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { parseISO, isValid } from "date-fns";
import LeadFormDialog from "../components/leads/LeadFormDialog";

// Shared Components
import StatusBadge from "../components/shared/StatusBadge";
import DashboardNotes from "../components/dashboard/DashboardNotes";
import ClientFormDialog from "../components/clients/ClientFormDialog";
import CreateQuoteFromTemplateDialog from "../components/shared/CreateQuoteFromTemplateDialog";
import ContinueWorking from "../components/dashboard/ContinueWorking";

const safeParseDate = (dateString) => {
  if (!dateString) return null;
  const parsed = parseISO(dateString);
  return isValid(parsed) ? parsed : null;
};

const getPlanIdFromPrice = (priceId) => {
  if (priceId === 'price_1U5xhnIfI96QPT6ldn9zJ04d') return 'starter';
  if (priceId === 'price_1U5xiGIfI96QPT6l04jhdNI7') return 'professional';
  if (priceId === 'price_1U5xjOIfI96QPT6laB6ZTAqy' || priceId === 'price_1U5xjOIfI96QPT6lJdMd9VCs') return 'enterprise';
  return 'starter'; 
};

export default function Dashboard() {
  const navigate = useNavigate(); 
  const qc = useQueryClient();
  const { profile } = useAuth();
  const companyId = profile?.company_id;
  
  // 👇 --- STRIPE CHECKOUT CATCHER --- 👇
  const [isRedirectingToStripe, setIsRedirectingToStripe] = useState(false);

  useEffect(() => {
    const triggerPendingCheckout = async () => {
      const pendingPriceId = localStorage.getItem('pending_stripe_checkout');
      
      const urlParams = new URLSearchParams(window.location.search);
      const isSuccess = urlParams.get('success');
      const isCanceled = urlParams.get('canceled');

      if (isSuccess || isCanceled) {
        localStorage.removeItem('pending_stripe_checkout');
        if (isSuccess) {
          toast.success("Subscription activated successfully!");
        }
        return; 
      }

      if (pendingPriceId) {
        setIsRedirectingToStripe(true);
        const internalPlanId = getPlanIdFromPrice(pendingPriceId);

        try {
          const { data, error } = await supabase.functions.invoke('create-checkout', {
            body: { 
              price_id: pendingPriceId,
              plan_id: internalPlanId 
            }
          });

          if (error) throw error;
          localStorage.removeItem('pending_stripe_checkout');
          if (data?.url) {
            window.location.href = data.url;
          }
        } catch (error) {
          console.error("Failed to generate checkout:", error);
          setIsRedirectingToStripe(false);
          localStorage.removeItem('pending_stripe_checkout'); 
        }
      }
    };

    triggerPendingCheckout();
  }, []);

  // 👇 --- GOOGLE SSO INVITE CATCHER --- 👇
  useEffect(() => {
    const checkInviteStatus = async () => {
      const isCheckingInvite = localStorage.getItem('checking_invite_status');
      
      if (!isCheckingInvite) return;

      // 1. Delete the flag so this only runs once
      localStorage.removeItem('checking_invite_status');

      // 2. Get the current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !user.email) return;

      // 3. Check if the invite STILL exists in the database
      const { data: invites, error } = await supabase
        .from('team_invites')
        .select('id')
        .eq('email', user.email);

      if (error) {
        console.error("Error checking invite:", error);
        return;
      }

      // 4. Determine if it failed or succeeded
      if (invites && invites.length > 0) {
        // The invite is still there. The SQL trigger bypassed it.
        toast.error(
          "Invitation failed: You already belong to a FuzedFlow company! One email can only belong to one company.", 
          { duration: 8000 }
        );
      } else {
        // The invite is gone. The SQL trigger successfully consumed it!
        toast.success("Successfully joined the team! Welcome to FuzedFlow.");
      }
    };

    checkInviteStatus();
  }, []);
  // 👆 ------------------------------------------------ 👆

  
  // --- INTERACTIVE STATES ---
  const [expandedProject, setExpandedProject] = useState(null);
  const [expandedLead, setExpandedLead] = useState(null);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isLeadDialogOpen, setIsLeadDialogOpen] = useState(false);

  // Task Form State
  const [taskForm, setTaskForm] = useState({
    title: "", description: "", project_id: "none", status: "Pending", priority: "Medium", due_date_target: "", assigned_to: "unassigned"
  });

  // --- QUERIES ---
  const { data: leads = [] } = useQuery({ 
    queryKey: ["leads", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("leads").select("*").order("created_at", { ascending: false }); return data || []; } 
  });
  
  const { data: quotes = [] } = useQuery({ 
    queryKey: ["quotes", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("quotes").select("*").order("created_at", { ascending: false }); return data || []; } 
  });
  
  const { data: projects = [] } = useQuery({ 
    queryKey: ["projects", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("projects").select("*").order("created_at", { ascending: false }); return data || []; } 
  });

  const { data: clients = [] } = useQuery({ 
    queryKey: ["clients", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("clients").select("*"); return data || []; } 
  });
  
  const { data: invoices = [] } = useQuery({ 
    queryKey: ["invoices", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("invoices").select("*").order("created_at", { ascending: false }); return data || []; } 
  });

  const { data: changeOrders = [] } = useQuery({ 
    queryKey: ["change_orders", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("change_orders").select("*").order("created_at", { ascending: false }); return data || []; } 
  });
  
  // READING PROJECT TASKS (Not simple tasks)
  const { data: projectTasks = [] } = useQuery({ 
    queryKey: ["project_tasks", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("project_tasks").select("*").eq("company_id", companyId).order("created_at", { ascending: false }); return data || []; } 
  });

  // FETCH USERS (Combines users and profiles safely)
  const { data: users = [] } = useQuery({
    queryKey: ["company_users", companyId], enabled: !!companyId,
    queryFn: async () => {
      const { data: usersData } = await supabase.from("users").select("id, full_name, email").eq("company_id", companyId);
      const { data: profilesData } = await supabase.from("profiles").select("id, full_name").eq("company_id", companyId);
      return [...(usersData || []), ...(profilesData || [])];
    }
  });

  // --- MUTATIONS ---
  const createLeadMutation = useMutation({
    mutationFn: async (data) => {
      const { error } = await supabase.from("leads").insert([{ ...data, company_id: companyId }]);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      toast.success("Lead created successfully!");
    },
  });

  const saveTaskMutation = useMutation({
    mutationFn: async (payload) => {
      const assignedToArray = payload.assigned_to && payload.assigned_to !== "unassigned" ? [payload.assigned_to] : null;
      const { error } = await supabase.from("project_tasks").insert([{
        company_id: companyId,
        title: payload.title,
        description: payload.description,
        project_id: payload.project_id === "none" ? null : payload.project_id,
        status: payload.status,
        priority: payload.priority,
        due_date_target: payload.due_date_target || null,
        assigned_to: assignedToArray
      }]);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["project_tasks"] });
      toast.success("Task created successfully!");
      setIsTaskModalOpen(false);
      setTaskForm({ title: "", description: "", project_id: "none", status: "Pending", priority: "Medium", due_date_target: "", assigned_to: "unassigned" });
    },
    onError: (err) => toast.error(`Failed to create task: ${err.message}`)
  });

  const handleSaveTask = (e) => {
    e.preventDefault();
    if (!taskForm.title.trim()) return toast.error("Title is required.");
    saveTaskMutation.mutate(taskForm);
  };

  // --- DERIVED STATE & FILTERING ---
  
  // Urgent items: Overdue OR explicitly marked as 'Urgent' priority
  const urgentTasks = projectTasks.filter(t => {
    if (["Completed", "Done"].includes(t.status)) return false;
    
    const isUrgentPriority = t.priority === "Urgent";
    const dueDate = safeParseDate(t.due_date_target);
    const isOverdue = dueDate && dueDate < new Date();
    
    return isUrgentPriority || isOverdue;
  });
  const urgentCount = urgentTasks.length;
  
  const activeProjects = projects.filter(p => !["Completed", "Closed", "Canceled", "Archived"].includes(p.status));
  const pendingQuotes = quotes.filter(q => ["Draft", "Sent"].includes(q.status));
  const activeLeads = leads.filter(l => !["Won", "Lost"].includes(l.pipeline_stage));
  
  const formatCurrency = (val) => val ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val) : '$0.00';
  
  const getClientName = (clientId) => {
    const client = clients.find(c => c.id === clientId);
    return client ? (client.name || `${client.first_name || ''} ${client.surname || ''}`.trim()) : 'Unknown Client';
  };

  // 👇 --- HIJACK THE SCREEN IF REDIRECTING --- 👇
  if (isRedirectingToStripe) {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center bg-slate-50">
        <Loader2 className="h-12 w-12 animate-spin text-amber-500 mb-4" />
        <h2 className="text-xl font-bold text-slate-900">Preparing your secure checkout...</h2>
        <p className="text-slate-500 mt-2">Redirecting to Stripe securely</p>
      </div>
    );
  }
  // 👆 ------------------------------------------------ 👆

  // ... YOUR EXISTING `return ( <div className="flex-1 p-6"> ... )` GOES HERE ...

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 pb-20">
      
      {/* 1. URGENT NOTIFICATION BAR + CREATE TASK */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          {urgentCount > 0 ? (
            <div 
              onClick={() => navigate('/Tasks')}
              className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-xl shadow-sm flex items-center justify-between cursor-pointer hover:bg-red-100 transition-colors h-full"
            >
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-full p-2 animate-pulse shrink-0">
                  <AlertTriangle className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-red-900">Urgent Attention Required</h3>
                  <p className="text-sm text-red-700">You have {urgentCount} urgent or overdue tasks.</p>
                </div>
              </div>            
              <Button variant="ghost" size="sm" className="hidden sm:flex text-red-700 hover:text-red-900 hover:bg-red-200">
                View All <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          ) : (
            <div 
              onClick={() => navigate('/Tasks')}
              className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl flex items-center justify-between cursor-pointer hover:bg-emerald-100 transition-colors h-full shadow-sm"
            >
              <div className="flex items-center gap-3 text-emerald-800 font-medium">
                <div className="h-3 w-3 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] shrink-0"></div>
                All clear! No overdue tasks today.
              </div>
              <Button variant="ghost" size="sm" className="hidden sm:flex text-emerald-700 hover:text-emerald-900 hover:bg-emerald-200">
                View All <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </div>

        {/* Create Task Button attached to the Urgent Banner row */}
        <Button 
          onClick={() => setIsTaskModalOpen(true)}
          className="bg-slate-900 hover:bg-slate-800 text-white font-bold h-auto py-4 sm:py-0 px-6 rounded-xl shadow-sm flex-shrink-0"
        >
          <CheckSquare className="h-5 w-5 mr-2" /> New Task
        </Button>
      </div>

      {/* Greeting */}
      <div>
        <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
          Let's get to work, {profile?.full_name?.split(' ')[0] || 'Admin'}.
        </h1>
        <p className="text-slate-500 font-medium mt-1">Here is what's on the docket today.</p>
      </div>

      {/* 2. ACTION BAR */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
        
        {/* Quote Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button className="h-14 sm:h-16 text-sm sm:text-base font-bold shadow-md transition-all hover:-translate-y-0.5 bg-amber-400 hover:bg-amber-500 text-slate-900 border-2 border-slate-900 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] hover:shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]">
              <FileText className="h-5 w-5 mr-2 text-slate-900" /> Create Quote
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56 font-medium">
            <DropdownMenuItem onClick={() => navigate("/QuoteBuilder?create=true")} className="cursor-pointer py-3">
              <FileText className="mr-2 h-4 w-4" /> New Blank Quote
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setIsTemplateModalOpen(true)} className="cursor-pointer py-3">
              <LayoutTemplate className="mr-2 h-4 w-4" /> Start from Template
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button 
          onClick={() => setIsLeadDialogOpen(true)} 
          className="h-14 sm:h-16 text-sm sm:text-base font-bold shadow-md transition-all hover:-translate-y-0.5 bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200"
        >
          <Target className="h-5 w-5 mr-2 text-slate-400" /> New Lead
        </Button>
        <Button onClick={() => setIsClientModalOpen(true)} className="h-14 sm:h-16 text-sm sm:text-base font-bold shadow-md transition-all hover:-translate-y-0.5 bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-200">
          <Users className="h-5 w-5 mr-2 text-slate-400" /> New Client
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
        
        {/* LEFT COLUMN: Workflow & Pipeline */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* 3. CONTINUE WORKING */}
          <ContinueWorking quotes={quotes} invoices={invoices} clients={clients} />

          {/* 4. SALES PIPELINE (Leads) */}
          <Card className="p-5 md:p-6 border-slate-200 shadow-sm bg-white flex flex-col gap-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Target className="h-5 w-5 text-amber-500" /> Sales Pipeline
              </h3>
              <Button variant="ghost" size="sm" onClick={() => navigate('/LeadTracker')} className="text-slate-500 hover:text-slate-900">
                View All Leads
              </Button>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {["New", "Contacted", "Booked Visit", "Quoted", "Negotiation", "Won"].map(stage => {
                const count = leads.filter(l => l.pipeline_stage === stage).length;
                return (
                  <div key={stage} className="text-center p-3 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-100">
                    <p className="text-xl font-black text-slate-800">{count}</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mt-1">{stage}</p>
                  </div>
                );
              })}
            </div>

            <div className="space-y-3 mt-2">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Most Recent Leads</h4>
              {activeLeads.slice(0, 3).map(lead => (
                <div key={lead.id} className="border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm transition-all">
                  <div className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50" onClick={() => setExpandedLead(expandedLead === lead.id ? null : lead.id)}>
                    <div>
                      <h4 className="font-bold text-slate-900">{lead.contact_name}</h4>
                      <p className="text-sm text-slate-500">{lead.source || 'General Inquiry'}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusBadge status={lead.pipeline_stage} />
                      {expandedLead === lead.id ? <ChevronUp className="h-5 w-5 text-slate-400" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                    </div>
                  </div>
                  {expandedLead === lead.id && (
                    <div className="p-4 border-t border-slate-100 bg-slate-50 animate-in slide-in-from-top-2 flex flex-col gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><DollarSign className="h-3 w-3"/> Est. Value</p>
                          <p className="font-semibold text-slate-900">{formatCurrency(lead.value_estimate)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><Phone className="h-3 w-3"/> Phone</p>
                          <p className="font-medium text-slate-900">{lead.contact_phone || 'N/A'}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><Mail className="h-3 w-3"/> Email</p>
                          <p className="font-medium text-slate-900">{lead.contact_email || 'N/A'}</p>
                        </div>
                      </div>
                      <Button onClick={() => navigate(`/LeadDetail?id=${lead.id}`)} className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold">
                        Open Lead Profile <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
              {activeLeads.length === 0 && (
                <div className="text-center py-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <p className="text-sm font-medium text-slate-500">No active leads right now.</p>
                </div>
              )}
            </div>
          </Card>

          {/* 5. ACTIVE PROJECTS */}
          <Card className="p-5 md:p-6 border-slate-200 shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FolderKanban className="h-5 w-5 text-amber-500" /> Active Projects
              </h3>
              <Button variant="ghost" size="sm" onClick={() => navigate('/PMProjects')} className="text-slate-500 hover:text-slate-900">
                View All Projects
              </Button>
            </div>

            <div className="space-y-3">
              {activeProjects.slice(0, 3).map(project => (
                <div key={project.id} className="border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm transition-all">
                  <div className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50" onClick={() => setExpandedProject(expandedProject === project.id ? null : project.id)}>
                    <div>
                      <h4 className="font-bold text-slate-900">{project.name}</h4>
                      <p className="text-sm text-slate-500">{getClientName(project.client_id)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusBadge status={project.status} />
                      {expandedProject === project.id ? <ChevronUp className="h-5 w-5 text-slate-400" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                    </div>
                  </div>
                  {expandedProject === project.id && (
                    <div className="p-4 border-t border-slate-100 bg-slate-50 animate-in slide-in-from-top-2 flex flex-col gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><DollarSign className="h-3 w-3"/> Contract Value</p>
                          <p className="font-semibold text-slate-900">{formatCurrency(project.budget || project.budget_revenue)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><CalendarDays className="h-3 w-3"/> Start Date</p>
                          <p className="font-medium text-slate-900">{project.start_date ? new Date(project.start_date).toLocaleDateString() : 'TBD'}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-xs text-slate-500 font-bold uppercase flex items-center gap-1 mb-1"><MapPin className="h-3 w-3"/> Address</p>
                          <p className="font-medium text-slate-900">{project.site_address || 'N/A'}</p>
                        </div>
                      </div>
                      <Button onClick={() => navigate(`/ProjectDetail?id=${project.id}`)} className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold">
                        Open Project Workspace <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
              {activeProjects.length === 0 && (
                <div className="text-center py-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <FolderKanban className="h-8 w-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-500">No active projects right now.</p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* RIGHT COLUMN: Field Notes & Tasks */}
        <div className="space-y-6">
          <div className="h-full">
            <DashboardNotes />
          </div>
        </div>

      </div>

      {/* --- INLINE MODALS FOR QUICK CREATION --- */}

      {/* Task Creation Modal */}
      <Dialog open={isTaskModalOpen} onOpenChange={setIsTaskModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveTask} className="space-y-4 pt-4">
            <div>
              <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Task Title *</Label>
              <Input value={taskForm.title} onChange={e => setTaskForm({...taskForm, title: e.target.value})} placeholder="e.g. Order materials" className="mt-1" required />
            </div>
            <div>
              <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Description</Label>
              <textarea value={taskForm.description} onChange={e => setTaskForm({...taskForm, description: e.target.value})} placeholder="Optional details..." className="mt-1 flex min-h-[80px] w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 disabled:cursor-not-allowed disabled:opacity-50" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Project</Label>
                <Select value={taskForm.project_id} onValueChange={v => setTaskForm({...taskForm, project_id: v})}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select Project" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Project</SelectItem>
                    {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Assignee</Label>
                <Select value={taskForm.assigned_to} onValueChange={v => setTaskForm({...taskForm, assigned_to: v})}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Unassigned" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                    {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Status</Label>
                <Select value={taskForm.status} onValueChange={v => setTaskForm({...taskForm, status: v})}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Pending", "Active", "Under Review", "Completed"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Priority</Label>
                <Select value={taskForm.priority} onValueChange={v => setTaskForm({...taskForm, priority: v})}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Low", "Medium", "High", "Urgent"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Target Date</Label>
                <Input type="date" value={taskForm.due_date_target} onChange={e => setTaskForm({...taskForm, due_date_target: e.target.value})} className="mt-1 block w-full" />
              </div>
            </div>
            <DialogFooter className="pt-4 border-t border-slate-100">
              <Button type="button" variant="ghost" onClick={() => setIsTaskModalOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saveTaskMutation.isPending} className="bg-blue-600 hover:bg-blue-700 text-white font-bold">
                {saveTaskMutation.isPending ? "Saving..." : "Save Task"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Quote Template Modal */}
      {isTemplateModalOpen && (
        <CreateQuoteFromTemplateDialog 
          open={isTemplateModalOpen} 
          onOpenChange={setIsTemplateModalOpen} 
        />
      )}

      {/* Client Modal */}
      {isClientModalOpen && (
        <ClientFormDialog 
          open={isClientModalOpen} 
          onOpenChange={setIsClientModalOpen} 
          onSuccess={() => {
            qc.invalidateQueries(["clients"]); 
            setIsClientModalOpen(false);
          }}
        />
      )}

{/* LEAD CREATION MODAL */}
      <LeadFormDialog 
        open={isLeadDialogOpen} 
        onOpenChange={setIsLeadDialogOpen} 
        users={users} 
        onSave={(data) => createLeadMutation.mutate(data)} 
      />
    </div>
  );
}