import React, { useState, useMemo } from "react";
import { supabase } from "@/api/supabaseClient"; 
import { useAuth } from "@/lib/AuthContext"; 
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mail, Phone, MapPin, Building2, ArrowLeft, Plus, LayoutTemplate, 
  Upload, FileText, Image as ImageIcon, ExternalLink, Trash2, Pencil, 
  ListChecks, Search, Calendar, AlertCircle, ChevronLeft, ChevronRight, 
  Edit2, Flame, CalendarPlus, MoreVertical 
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import CreateQuoteFromTemplateDialog from "../components/shared/CreateQuoteFromTemplateDialog";
import CommunicationPanel from "../components/clients/CommunicationPanel";
import { Link } from "react-router-dom";
import StatusBadge from "../components/shared/StatusBadge";
import NotesFeed from "../components/shared/NotesFeed";
import AddressAutocomplete from "../components/shared/AddressAutocomplete";
import { format, parseISO, isValid } from "date-fns";
import { toast } from "sonner";

// IMPORT THE SHARED DIALOG
import CreateTaskDialog from "../components/tasks/CreateTaskDialog"; // ADJUST PATH IF NEEDED

// --- HELPERS FOR TASKS ---
const STATUSES = ["Pending", "Active", "Under Review", "Completed", "To Do", "Doing", "Blocked", "Done"];
const PRIORITIES = ["Low", "Medium", "High", "Urgent"];
const ITEMS_PER_PAGE = 15;

const safeParseDate = (dateString) => {
  if (!dateString) return null;
  const parsed = parseISO(dateString);
  return isValid(parsed) ? parsed : null;
};

const normalizeStatus = (dbStatus) => {
  const s = dbStatus?.toLowerCase() || "";
  if (s.includes("to do") || s === "pending") return "Pending";
  if (s.includes("progress") || s.includes("active") || s.includes("doing")) return "Active";
  if (s.includes("review") || s.includes("blocked")) return "Under Review";
  if (s.includes("done") || s.includes("complete")) return "Completed";
  return "Pending";
};

const getPriorityColor = (priority) => {
  switch (priority?.toLowerCase()) {
    case "urgent": return "text-white bg-red-600 border-red-700 shadow-md ring-2 ring-red-200 animate-pulse";
    case "high": return "text-red-800 bg-red-100 border-red-300";
    case "medium": return "text-amber-800 bg-amber-100 border-amber-300";
    case "low": return "text-green-800 bg-green-100 border-green-300";
    default: return "text-slate-600 bg-slate-100 border-slate-200";
  }
};

export default function ClientDetail() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;

  const params = new URLSearchParams(window.location.search);
  const clientId = params.get("id");
  const queryClient = useQueryClient();
  
  const [uploadDialog, setUploadDialog] = useState(false);
  const [uploadType, setUploadType] = useState("site_photos");
  const [uploading, setUploading] = useState(false);
  const [editDialog, setEditDialog] = useState(false);
  
  const [editForm, setEditForm] = useState({ 
    name: "", type: "", primary_contact_name: "", email: "", phone: "", billing_address: "", site_address: "" 
  });

  // 1. FETCH CLIENT
  const { data: client } = useQuery({
    queryKey: ["client", clientId],
    enabled: !!clientId,
    queryFn: async () => {
      const { data, error } = await supabase.from("clients").select("*").eq("id", clientId).single();
      if (error) throw error;
      return data;
    },
  });

  // 2. FETCH RELATED DATA
  const { data: quotes = [] } = useQuery({
    queryKey: ["client-quotes", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("quotes").select("*").eq("client_id", clientId).eq("company_id", companyId);
      if (error && error.code !== '42P01') throw error; 
      return data || [];
    },
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["client-projects", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").eq("client_id", clientId).eq("company_id", companyId);
      if (error && error.code !== '42P01') throw error;
      return data || [];
    },
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ["client-invoices", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("invoices").select("*").eq("client_id", clientId).eq("company_id", companyId);
      if (error && error.code !== '42P01') throw error;
      return data || [];
    },
  });

  const { data: changeOrders = [] } = useQuery({
    queryKey: ["client-change-orders", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("change_orders").select("*").eq("client_id", clientId).eq("company_id", companyId);
      if (error && error.code !== '42P01') throw error;
      return data || [];
    },
  });

  const { data: leads = [] } = useQuery({
    queryKey: ["client-leads", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("leads").select("*").eq("client_id", clientId).eq("company_id", companyId);
      if (error && error.code !== '42P01') throw error;
      return data || [];
    },
  });

  const { data: attachments = [] } = useQuery({
    queryKey: ["client-attachments", clientId],
    enabled: !!clientId && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("attachments")
        .select("*")
        .eq("related_type", "Client")
        .eq("related_id", clientId)
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // 3. MUTATIONS
  const deleteAttachmentMutation = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from("attachments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client-attachments", clientId] });
      toast.success("File deleted");
    },
  });

  const updateClientMutation = useMutation({
    mutationFn: async (data) => {
      const { error } = await supabase.from("clients").update(data).eq("id", clientId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client", clientId] });
      toast.success("Client updated");
      setEditDialog(false);
    },
  });

  const handleOpenEdit = () => {
    setEditForm({
      name: client?.name || "",
      type: client?.type || "Homeowner",
      primary_contact_name: client?.primary_contact_name || "",
      email: client?.email || "",
      phone: client?.phone || "",
      billing_address: client?.billing_address || "",
      site_address: client?.site_address || "",
    });
    setEditDialog(true);
  };

  const handleSaveEdit = () => {
    updateClientMutation.mutate(editForm);
  };

  const updateTaskMutation = useMutation({
    mutationFn: async (payload) => {
      let safeAssignedTo = null;
      if (Array.isArray(payload.assigned_to) && payload.assigned_to.length > 0) {
        safeAssignedTo = payload.assigned_to;
      } else if (typeof payload.assigned_to === "string" && payload.assigned_to !== "none" && payload.assigned_to.trim() !== "") {
        safeAssignedTo = [payload.assigned_to];
      }

      const dbPayload = { 
        title: payload.title,
        description: payload.description || null,
        priority: payload.priority || "Medium", 
        status: payload.status || "To Do",
        project_id: payload.project_id === "none" || !payload.project_id ? null : payload.project_id,
        due_date_target: payload.due_date_target || null,
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: safeAssignedTo,
      };
      
      console.log("🚀 SAVING TASK TO DB:", dbPayload);

      const { error } = await supabase.from("project_tasks").update(dbPayload).eq("id", payload.id);
      if (error) {
        console.error("❌ SUPABASE REJECTED SAVE:", error);
        throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_tasks_full", clientId] });
      toast.success("Task updated successfully!");
      setEditDialogOpen(false); 
    },
    onError: (err) => {
      console.error("❌ MUTATION ERROR:", err);
      toast.error(`Database rejected save: ${err.message}`);
    }
  });

  const handleFileUpload = async (files) => {
    setUploading(true);
    try {
      const fileArray = Array.from(files);
      
      for (const file of fileArray) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${clientId}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('attachments')
          .upload(fileName, file);
          
        if (uploadError) throw uploadError;
        
        const { data: { publicUrl } } = supabase.storage
          .from('attachments')
          .getPublicUrl(fileName);
          
        let caption = "Site Photos/Info";
        if (uploadType === "subcontractor_quotes" || uploadType === "subcontractor_quote") {
          caption = "Subcontractor Quote";
        }

        const { error: dbError } = await supabase.from('attachments').insert([{
          company_id: companyId,
          related_type: "Client",
          related_id: clientId,
          file_url: publicUrl,
          file_name: file.name,
          caption: caption
        }]);
        
        if (dbError) throw dbError;
      }
      
      queryClient.invalidateQueries({ queryKey: ["client-attachments", clientId] });
      toast.success("Files uploaded successfully");
      setUploadDialog(false);
    } catch (error) {
      toast.error("Upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const sitePhotos = attachments.filter(a => a.caption === "Site Photos/Info");
  const subcontractorQuotes = attachments.filter(a => a.caption === "Subcontractor Quote");

  if (!client) return <div className="p-6 text-slate-500">Loading client profile...</div>;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <Link to="/Clients" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 mb-4 transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back to Clients
      </Link>

      <Card className="p-6 mb-6 border-slate-200/80 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900">{client.name}</h1>
            <p className="text-sm text-slate-500">{client.type} · {client.primary_contact_name}</p>
          </div>
          <Button onClick={handleOpenEdit} className="bg-slate-900 hover:bg-slate-800 text-white font-bold w-full sm:w-auto shadow-sm">
            <Pencil className="h-4 w-4 mr-2" /> Edit Client
          </Button>
        </div>
        <div className="grid sm:grid-cols-2 gap-4 mt-4">
          {client.email && <p className="text-sm text-slate-600 flex items-center gap-2"><Mail className="h-4 w-4 text-slate-400" /> {client.email}</p>}
          {client.phone && <p className="text-sm text-slate-600 flex items-center gap-2"><Phone className="h-4 w-4 text-slate-400" /> {client.phone}</p>}
          {client.billing_address && <p className="text-sm text-slate-600 flex items-center gap-2"><Building2 className="h-4 w-4 text-slate-400" /> <span className="text-xs">Billing: {client.billing_address}</span></p>}
          {client.site_address && <p className="text-sm text-slate-600 flex items-center gap-2"><MapPin className="h-4 w-4 text-slate-400" /> <span className="text-xs">Site: {client.site_address}</span></p>}
        </div>
      </Card>

      <Tabs defaultValue="communications">
        <TabsList className="mb-4 flex-wrap h-auto bg-slate-100/50">
          <TabsTrigger value="communications">Communications</TabsTrigger>
          <TabsTrigger value="files">Files ({attachments.length})</TabsTrigger>
          <TabsTrigger value="notes">Notes & Tasks</TabsTrigger>
          <TabsTrigger value="leads">Leads ({leads.length})</TabsTrigger>
          <TabsTrigger value="quotes">Quotes ({quotes.length})</TabsTrigger>
          <TabsTrigger value="change_orders">Change Orders ({changeOrders.length})</TabsTrigger>
          <TabsTrigger value="projects">Projects ({projects.length})</TabsTrigger>
          <TabsTrigger value="invoices">Invoices ({invoices.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="communications">
          <CommunicationPanel 
            clientId={clientId}
            clientEmail={client.email}
            clientPhone={client.phone}
            clientName={client.name}
          />
        </TabsContent>

        <TabsContent value="files">
          <div className="mb-4">
            <Button onClick={() => setUploadDialog(true)} className="bg-gradient-to-br from-amber-500 to-amber-600 text-slate-900 shadow-sm hover:shadow font-bold">
              <Upload className="h-4 w-4 mr-2" />
              Upload Documents/Photos
            </Button>
          </div>

          <div className="space-y-6">
            <Card className="p-4 border-2 border-amber-400/50 shadow-sm">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <ImageIcon className="h-4 w-4 text-amber-600" />
                Site Photos/Info ({sitePhotos.length})
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {sitePhotos.map(file => {
                  const isImage = file.file_name?.match(/\.(jpg|jpeg|png|gif|webp)$/i);
                  const isVideo = file.file_name?.match(/\.(mp4|mov|webm|avi)$/i);
                  
                  return (
                    <div key={file.id} className="relative group">
                      {isImage ? (
                        <a href={file.file_url} target="_blank" rel="noopener noreferrer" className="block relative">
                          <img src={file.file_url} alt={file.file_name} className="w-full h-32 object-cover rounded border-2 border-slate-200 hover:border-amber-400 transition-all" />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-center justify-center rounded">
                            <ExternalLink className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </a>
                      ) : isVideo ? (
                        <div className="block relative h-32 w-full rounded border-2 border-slate-200 hover:border-amber-400 transition-all overflow-hidden bg-black">
                          <video className="w-full h-full object-cover" controls preload="metadata">
                            <source src={file.file_url} />
                            Your browser does not support the video tag.
                          </video>
                        </div>
                      ) : (
                        <a href={file.file_url} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center justify-center h-32 bg-slate-50 rounded border-2 border-slate-200 hover:border-amber-400 transition-all group">
                          <FileText className="h-8 w-8 text-slate-400 group-hover:text-amber-600 mb-2" />
                          <p className="text-xs text-slate-600 text-center px-2 truncate w-full">{file.file_name}</p>
                        </a>
                      )}
                      
                      <button
                        onClick={() => deleteAttachmentMutation.mutate(file.id)}
                        className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full h-6 w-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md z-10"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                      <p className="text-[10px] text-slate-500 mt-1 truncate">{file.file_name}</p>
                    </div>
                  );
                })}
              </div>
              {sitePhotos.length === 0 && (
                <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No site photos or info uploaded</p>
              )}
            </Card>

            <Card className="p-4 border-2 border-amber-400/50 shadow-sm">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <FileText className="h-4 w-4 text-amber-600" />
                Subcontractor Quotes ({subcontractorQuotes.length})
              </h3>
              <div className="space-y-2">
                {subcontractorQuotes.map(file => (
                  <a
                    key={file.id}
                    href={file.file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3 bg-slate-50 hover:bg-amber-50 rounded border border-slate-200 hover:border-amber-400 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-slate-400 group-hover:text-amber-600 shrink-0" />
                      <span className="text-sm font-medium text-slate-700 group-hover:text-amber-700">{file.file_name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">{file.created_at ? format(new Date(file.created_at), "MMM d, yyyy") : "—"}</span>
                      <ExternalLink className="h-4 w-4 text-slate-400 group-hover:text-amber-600" />
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          deleteAttachmentMutation.mutate(file.id);
                        }}
                        className="text-slate-400 hover:text-red-600 hover:bg-red-50 h-8 w-8 rounded flex items-center justify-center transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </a>
                ))}
              </div>
              {subcontractorQuotes.length === 0 && (
                <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No subcontractor quotes uploaded</p>
              )}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="notes">
          <Tabs defaultValue="updates" className="w-full mt-2">
            <TabsList className="grid w-full sm:w-[400px] grid-cols-2 mb-4">
              <TabsTrigger value="updates" className="font-bold">Notes & Updates</TabsTrigger>
              <TabsTrigger value="tasks" className="font-bold">Client Tasks</TabsTrigger>
            </TabsList>

            <TabsContent value="updates">
              <Card className="p-0 sm:p-2 shadow-sm border-slate-200/80 bg-white overflow-hidden rounded-xl">
                <NotesFeed 
                  relatedType="Client" 
                  relatedId={client.id}
                  clientId={client.id} 
                />
              </Card>
            </TabsContent>

            <TabsContent value="tasks">
              <ClientTasksDashboard clientId={client.id} companyId={companyId} clientName={client.name} />
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="leads">
          <div className="space-y-2">
            {leads.map(lead => (
              <Card key={lead.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-700">{lead.contact_name}</p>
                  <p className="text-xs text-slate-500">{lead.source} · ${lead.value_estimate?.toLocaleString() || "—"}</p>
                </div>
                <StatusBadge status={lead.pipeline_stage} />
              </Card>
            ))}
            {leads.length === 0 && <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No leads associated with this client</p>}
          </div>
        </TabsContent>

        <TabsContent value="quotes">
          <div className="mb-4 flex flex-wrap gap-2">
            <CreateQuoteFromTemplateDialog clientId={clientId}>
              <Button variant="outline" className="gap-2 bg-white shadow-sm hover:shadow">
                <LayoutTemplate className="h-4 w-4" /> From Template
              </Button>
            </CreateQuoteFromTemplateDialog>
            <Link to={`/QuoteBuilder?client_id=${clientId}`}>
              <Button className="bg-gradient-to-br from-amber-500 to-amber-600 text-slate-900 shadow-sm hover:shadow">
                <Plus className="h-4 w-4 mr-2" />
                Create Quote
              </Button>
            </Link>
          </div>
          <div className="space-y-2">
            {quotes.map(q => (
              <Link key={q.id} to={`/QuoteBuilder?id=${q.id}`}>
                <Card className="p-4 flex items-center justify-between hover:border-amber-300 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-slate-700">{q.title}</p>
                    <p className="text-xs text-slate-500">{q.quote_number} · ${q.total?.toLocaleString() || "0"}</p>
                  </div>
                  <StatusBadge status={q.status} />
                </Card>
              </Link>
            ))}
            {quotes.length === 0 && <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No quotes created yet</p>}
          </div>
        </TabsContent>

        <TabsContent value="change_orders">
          <div className="mb-4 flex flex-wrap gap-2">
            <Link to={`/ChangeOrderBuilder?client_id=${clientId}`}>
              <Button className="bg-gradient-to-br from-amber-500 to-amber-600 text-slate-900 shadow-sm hover:shadow">
                <Plus className="h-4 w-4 mr-2" />
                Create Change Order
              </Button>
            </Link>
          </div>
          <div className="space-y-2">
            {changeOrders.map(co => (
              <Link key={co.id} to={`/ChangeOrderBuilder?id=${co.id}`}>
                <Card className="p-4 flex items-center justify-between hover:border-amber-300 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-slate-700">{co.title || "Untitled Change Order"}</p>
                    <p className="text-xs text-slate-500">{co.change_order_number} · ${co.total?.toLocaleString() || "0"}</p>
                  </div>
                  <StatusBadge status={co.status} />
                </Card>
              </Link>
            ))}
            {changeOrders.length === 0 && <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No change orders created yet</p>}
          </div>
        </TabsContent>

        <TabsContent value="projects">
          <div className="space-y-2">
            {projects.map(p => (
              <Link key={p.id} to={`/ProjectDetail?id=${p.id}`}>
                <Card className="p-4 flex items-center justify-between hover:border-amber-300 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-slate-700">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.project_number}</p>
                  </div>
                  <StatusBadge status={p.status} />
                </Card>
              </Link>
            ))}
            {projects.length === 0 && <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No active projects</p>}
          </div>
        </TabsContent>

        <TabsContent value="invoices">
          <div className="space-y-2">
            {invoices.map(inv => (
              <Card key={inv.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-700">{inv.invoice_number}</p>
                  <p className="text-xs text-slate-500">Total: ${inv.total?.toLocaleString() || "0"} · Due: ${inv.balance_due?.toLocaleString() || "0"}</p>
                </div>
                <StatusBadge status={inv.status} />
              </Card>
            ))}
            {invoices.length === 0 && <p className="text-sm text-slate-400 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">No invoices</p>}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={editDialog} onOpenChange={setEditDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Client Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div>
              <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Company / Client Name *</Label>
              <Input value={editForm.name} onChange={e => setEditForm({...editForm, name: e.target.value})} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Client Type</Label>
                <Select value={editForm.type} onValueChange={v => setEditForm({...editForm, type: v})}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Homeowner">Homeowner</SelectItem>
                    <SelectItem value="Builder">Builder</SelectItem>
                    <SelectItem value="Commercial">Commercial</SelectItem>
                    <SelectItem value="Property Manager">Property Manager</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Primary Contact</Label>
                <Input value={editForm.primary_contact_name} onChange={e => setEditForm({...editForm, primary_contact_name: e.target.value})} className="mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Email</Label>
                <Input type="email" value={editForm.email} onChange={e => setEditForm({...editForm, email: e.target.value})} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Phone</Label>
                <Input value={editForm.phone} onChange={e => setEditForm({...editForm, phone: e.target.value})} className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Billing Address</Label>
              <div className="mt-1">
                <AddressAutocomplete
                  value={editForm.billing_address || ""}
                  onChange={(v) => setEditForm({ ...editForm, billing_address: v })}
                  placeholder="Start typing billing address..."
                />
              </div>
            </div>
            <div>
              <Label className="text-xs font-bold uppercase tracking-wider text-slate-500">Site Address</Label>
              <div className="mt-1">
                <AddressAutocomplete
                  value={editForm.site_address || ""}
                  onChange={(v) => setEditForm({ ...editForm, site_address: v })}
                  placeholder="Start typing site/project address..."
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
              <Button variant="outline" onClick={() => setEditDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveEdit} disabled={!editForm.name} className="bg-slate-900 hover:bg-slate-800 text-white font-bold">
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={uploadDialog} onOpenChange={setUploadDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Documents/Photos</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>File Type *</Label>
              <Select value={uploadType} onValueChange={setUploadType}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="site_photos">Site Photos/Info</SelectItem>
                  <SelectItem value="subcontractor_quotes">Subcontractor Quotes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Select Files</Label>
              <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-slate-300 bg-slate-50 rounded-lg cursor-pointer hover:border-amber-400 hover:bg-amber-50 transition-colors mt-2">
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
                  disabled={uploading}
                />
                <Upload className={`h-8 w-8 text-slate-400 mb-2 ${uploading ? 'animate-bounce text-amber-500' : ''}`} />
                <span className="text-sm font-medium text-slate-600">
                  {uploading ? "Uploading securely..." : "Click to select files"}
                </span>
                <span className="text-xs text-slate-400 mt-1">PNG, JPG, PDF, DOC, MP4</span>
              </label>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setUploadDialog(false)} disabled={uploading}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ----------------------------------------------------------------------
// FULLY REBUILT CLIENT TASKS DASHBOARD
// ----------------------------------------------------------------------
function ClientTasksDashboard({ clientId, companyId, clientName }) {
  const qc = useQueryClient();

  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all"); 
  const [currentPage, setCurrentPage] = useState(1);

  // DIALOG STATES
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [viewingTask, setViewingTask] = useState(null);

  const [editForm, setEditForm] = useState({
    id: null,
    title: "",
    description: "",
    client_id: "none",
    project_id: "none",
    status: "Pending",
    priority: "Medium",
    due_date_target: "",
    estimated_hours: "",
    assigned_to: "none"
  });

// ⚡ THE MISSING MUTATION BELONGS EXACTLY HERE:
  const updateTaskMutation = useMutation({
    mutationFn: async (payload) => {
      let safeAssignedTo = null;
      if (Array.isArray(payload.assigned_to) && payload.assigned_to.length > 0) {
        safeAssignedTo = payload.assigned_to;
      } else if (typeof payload.assigned_to === "string" && payload.assigned_to !== "none" && payload.assigned_to.trim() !== "") {
        safeAssignedTo = [payload.assigned_to];
      }

      const dbPayload = { 
        title: payload.title,
        description: payload.description || null,
        priority: payload.priority || "Medium", 
        status: payload.status || "To Do",
        project_id: payload.project_id === "none" || !payload.project_id ? null : payload.project_id,
        due_date_target: payload.due_date_target || null,
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: safeAssignedTo,
      };
      
      console.log("🚀 SAVING TASK TO DB:", dbPayload);

      const { error } = await supabase.from("project_tasks").update(dbPayload).eq("id", payload.id);
      if (error) {
        console.error("❌ SUPABASE REJECTED SAVE:", error);
        throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_tasks_full", clientId] });
      toast.success("Task updated successfully!");
      setEditDialogOpen(false); 
    },
    onError: (err) => {
      console.error("❌ MUTATION ERROR:", err);
      toast.error(`Database rejected save: ${err.message}`);
    }
  });

  // QUERIES
  const { data: projects = [] } = useQuery({ 
    queryKey: ["client_projects_mapping", companyId], // Updated key
    enabled: !!companyId,
    queryFn: async () => {
      // ⚡ WIDENED SEARCH: Now pulling all company projects instead of just this one client's projects
      const { data } = await supabase
        .from("projects")
        .select("id, name, project_number")
        .eq("company_id", companyId); 
        
      return data || [];
    } 
  });

  const { data: users = [] } = useQuery({
    queryKey: ["company_users", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data: usersData } = await supabase.from("users").select("id, full_name, email").eq("company_id", companyId);
      const { data: profilesData } = await supabase.from("profiles").select("id, full_name").eq("company_id", companyId);
      return [...(usersData || []), ...(profilesData || [])];
    }
  });

  const { data: companyUsers = [] } = useQuery({
    queryKey: ["company_users", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, full_name").eq("company_id", companyId);
      return data || [];
    }
  });
  
  const { data: allTasks = [], isLoading } = useQuery({ 
  queryKey: ["client_tasks_full", clientId], 
  enabled: !!clientId,
  queryFn: async () => {
    const { data, error } = await supabase
      .from("project_tasks") // ⚡ FIXED: Changed from "tasks" to "project_tasks"
      .select("*")
      .eq("client_id", clientId)
      .order("created_at", { ascending: false });
      
    if (error) {
      console.error("❌ Task Fetch Error:", error);
      throw error;
    }
    return data || [];
  } 
});

  // Mock clients array specifically for this client context
  const clients = useMemo(() => [{ id: clientId, name: clientName || "Current Client" }], [clientId, clientName]);

  // MAPS
  const projectMap = useMemo(() => Object.fromEntries(projects.map(p => [p.id, p.name])), [projects]);
  const userMap = useMemo(() => Object.fromEntries(users.map(u => [u.id, u.full_name || u.email])), [users]);

  // MUTATIONS
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }) => {
      const { error } = await supabase.from("tasks").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["client_tasks_full"] }); toast.success("Status updated"); }
  });

  const handleCreateSubmit = useMutation({
    mutationFn: async (payload) => {
      const assignedToVal = payload.assigned_to && payload.assigned_to !== "none" ? payload.assigned_to : null;
      const taskPayload = {
        client_id: clientId,
        company_id: companyId,
        title: payload.title,
        description: payload.description || null,
        project_id: payload.project_id === "none" ? null : payload.project_id,
        status: payload.status || "To Do",
        priority: payload.priority || "Medium",
        due_date_target: payload.due_date || null,
        due_date: payload.due_date || null, // Keeping legacy field sync just in case
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: assignedToVal
      };
      const { error } = await supabase.from("tasks").insert([taskPayload]);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_tasks_full"] });
      setCreateDialogOpen(false);
      toast.success("Task created successfully!");
    },
    onError: (err) => toast.error(`Failed to create task: ${err.message}`)
  });

  const handleEditSubmit = useMutation({
    mutationFn: async (payload) => {
      const assignedToVal = payload.assigned_to && payload.assigned_to !== "none" ? payload.assigned_to : null;
      const taskPayload = {
        title: payload.title,
        description: payload.description || null,
        project_id: payload.project_id === "none" ? null : payload.project_id,
        client_id: payload.client_id === "none" ? null : payload.client_id,
        status: payload.status || "To Do",
        priority: payload.priority || "Medium",
        due_date_target: payload.due_date_target || null,
        due_date: payload.due_date_target || null, // Keeping legacy field sync just in case
        estimated_hours: payload.estimated_hours ? Number(payload.estimated_hours) : null,
        assigned_to: assignedToVal
      };
      const { error } = await supabase.from("tasks").update(taskPayload).eq("id", payload.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_tasks_full"] });
      setEditDialogOpen(false);
      toast.success("Task updated successfully!");
    },
    onError: (err) => toast.error(`Failed to update task: ${err.message}`)
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from("tasks").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["client_tasks_full"] }); toast.success("Task deleted."); }
  });

  // HANDLERS
  const openEditModal = (task) => {
    const assigneeVal = Array.isArray(task.assigned_to) ? task.assigned_to[0] : task.assigned_to;
    setEditForm({
      id: task.id,
      title: task.title || "",
      description: task.description || "",
      project_id: task.project_id ? String(task.project_id) : "none",
      client_id: task.client_id ? String(task.client_id) : "none",
      status: task.status || "Pending",
      priority: task.priority || "Medium",
      due_date_target: task.due_date_target || task.due_date || "",
      estimated_hours: task.estimated_hours || "",
      assigned_to: assigneeVal ? String(assigneeVal) : "none"
    });
    setEditDialogOpen(true);
  };

  const handleAddToCalendar = (task) => {
    const targetDate = task.due_date_target || task.due_date;
    if (!targetDate) return toast.error("Please set a target date on this task first!");
    const cleanDate = targetDate.replace(/-/g, "");
    const projectName = projectMap[task.project_id] || "No Project";
    const title = encodeURIComponent(`Task: ${task.title}`);
    const desc = encodeURIComponent(`${task.description || "No extra details."}\n\nProject: ${projectName}`);
    window.open(`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${cleanDate}/${cleanDate}&details=${desc}`, "_blank");
  };

  // FILTERING
  const filteredTasks = allTasks.filter(t => {
    const matchSearch = !search || t.title?.toLowerCase().includes(search.toLowerCase());
    const taskStatus = normalizeStatus(t.status);
    let matchStatus = filterStatus === "all" ? true : filterStatus === "unfinished" ? taskStatus !== "Completed" : taskStatus === filterStatus;
    return matchSearch && matchStatus;
  }).sort((a, b) => {
    const aComp = normalizeStatus(a.status) === "Completed";
    const bComp = normalizeStatus(b.status) === "Completed";
    const aDate = safeParseDate(a.due_date_target || a.due_date);
    const bDate = safeParseDate(b.due_date_target || b.due_date);
    const aOverdue = aDate && aDate < new Date() && !aComp;
    const bOverdue = bDate && bDate < new Date() && !bComp;

    if (!aComp && a.priority === "Urgent" && (bComp || b.priority !== "Urgent")) return -1;
    if (!bComp && b.priority === "Urgent" && (aComp || a.priority !== "Urgent")) return 1;
    if (aOverdue && !bOverdue) return -1;
    if (bOverdue && !aOverdue) return 1;
    return 0;
  });

  const totalPages = Math.ceil(filteredTasks.length / ITEMS_PER_PAGE);
  const indexOfLastItem = currentPage * ITEMS_PER_PAGE;
  const indexOfFirstItem = indexOfLastItem - ITEMS_PER_PAGE;
  const currentItems = filteredTasks.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <Card className="p-4 sm:p-6 shadow-sm border-slate-200/80 bg-white rounded-xl flex flex-col space-y-4">
      
      {/* HEADER & NEW TASK BUTTON */}
      <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-end">
        <div>
          <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ListChecks className="h-5 w-5 md:h-6 md:w-6 text-blue-600" /> Client Action Items
          </h3>
          <p className="text-xs md:text-sm font-bold text-slate-500 mt-1 uppercase tracking-wider">{filteredTasks.length} matching tasks</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)} className="bg-amber-500 hover:bg-amber-600 text-white font-bold shadow-md shrink-0 w-full sm:w-auto">
          <Plus className="h-4 w-4 mr-2" /> New Task
        </Button>
      </div>

      {/* FILTER BAR */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search task descriptions..." 
            value={search} 
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }} 
            className="pl-9 w-full bg-slate-50 font-medium h-10 border-slate-200" 
          />
        </div>
        <div className="w-full sm:w-[200px]">
          <Select value={filterStatus} onValueChange={(val) => { setFilterStatus(val); setCurrentPage(1); }}>
            <SelectTrigger className="w-full bg-slate-50 border-slate-200 font-bold h-10"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Every Status</SelectItem>
              <SelectItem value="unfinished" className="font-bold text-blue-700">All Unfinished</SelectItem>
              <div className="border-t border-slate-100 my-1"></div>
              {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* TASKS LIST */}
      <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50 md:bg-white flex flex-col min-h-[300px]">
        {isLoading ? (
          <div className="flex justify-center items-center py-20 flex-1">
            <div className="h-8 w-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="text-center py-16 px-4 bg-white flex-1">
            <ListChecks className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-700">No tasks found</h3>
            <p className="text-sm text-slate-500 mt-1">Check your search spelling or change your filters.</p>
          </div>
        ) : (
          <div className="w-full flex-1">
            {/* Desktop Table View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm text-left whitespace-nowrap border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-black text-slate-500 tracking-wider">
                  <tr>
                    <th className="px-4 py-3">Action Item</th>
                    <th className="px-4 py-3">Project</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Priority</th>
                    <th className="px-4 py-3">Target Date</th>
                    <th className="px-4 py-3">Assigned To</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {currentItems.map(task => {
                    const dueDateObj = safeParseDate(task.due_date_target || task.due_date);
                    const isCompleted = normalizeStatus(task.status) === "Completed";
                    const isOverdue = dueDateObj && dueDateObj < new Date() && !isCompleted;
                    const isUrgent = task.priority?.toLowerCase() === "urgent" && !isCompleted;
                    const isHigh = task.priority?.toLowerCase() === "high" && !isCompleted;

                    let assignees = [];
                    if (Array.isArray(task.assigned_to)) {
                      assignees = task.assigned_to.map(id => userMap[id]).filter(Boolean);
                    } else if (task.assigned_to && userMap[task.assigned_to]) {
                      assignees = [userMap[task.assigned_to]];
                    }

                    let rowClass = "transition-all hover:bg-slate-50 relative group";
                    if (isCompleted) rowClass = "transition-all bg-slate-50 opacity-60 relative";
                    else if (isOverdue) rowClass = "transition-all bg-rose-50/70 hover:bg-rose-100/80 relative group";
                    else if (isUrgent) rowClass = "transition-all bg-red-50 hover:bg-red-100 relative group";
                    else if (isHigh) rowClass = "transition-all bg-orange-50/30 hover:bg-orange-50 relative group";

                    return (
                      <tr key={task.id} className={rowClass}>
                        <td className="px-4 py-3 relative">
                          {!isCompleted && (isOverdue || isUrgent) && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-red-600"></div>}
                          {!isCompleted && isHigh && !isOverdue && <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-400"></div>}

                          <div className="flex items-start gap-2 pl-1">
                            {!isCompleted && isUrgent && <Flame className="h-4 w-4 text-red-600 fill-red-600 animate-bounce shrink-0 mt-0.5" />}
                            <button type="button" className="text-left cursor-pointer group/text focus:outline-none" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setViewingTask(task); }}>
                              <p className={`font-bold truncate max-w-[200px] xl:max-w-[280px] group-hover/text:text-blue-600 group-hover/text:underline transition-colors ${isCompleted ? 'text-slate-500 line-through' : (isUrgent || isOverdue) ? 'text-red-900 font-extrabold' : 'text-slate-900'}`}>{task.title}</p>
                              {task.description && <p className={`text-[10px] mt-0.5 truncate max-w-[200px] xl:max-w-[280px] group-hover/text:text-blue-600 transition-colors ${(isUrgent || isOverdue) ? 'text-red-700/70 font-semibold' : 'text-slate-500'}`}>{task.description}</p>}
                            </button>
                          </div>
                        </td>
                        
                        <td className="px-4 py-3">
  {task.project_id ? (
    <Badge variant="outline" className={`text-[10px] uppercase tracking-wider border-slate-200 ${(isUrgent || isOverdue) ? 'bg-white/70 text-red-800 font-bold border-red-200' : 'bg-white'}`}>
      {(() => {
        // ⚡ Look up the project directly from the database results
        const matchedProject = projects.find(p => String(p.id) === String(task.project_id));
        // Fallback to project_number if the name is blank!
        return matchedProject ? (matchedProject.name || `Project #${matchedProject.project_number}`) : "Unknown Project";
      })()}
    </Badge>
  ) : <span className="text-xs text-slate-400 italic">—</span>}
</td>
                        
                        <td className="px-4 py-3">
                          <Select value={normalizeStatus(task.status)} onValueChange={v => updateStatusMutation.mutate({ id: task.id, status: v })}>
                            <SelectTrigger className={`w-[130px] h-8 text-xs font-bold ${isCompleted ? 'bg-green-50 text-green-700 border-green-200' : (isUrgent || isOverdue) ? 'bg-white border-red-300 text-red-900 shadow-sm' : 'bg-white'}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {STATUSES.map(s => <SelectItem key={s} value={s} className="text-xs font-bold">{s}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </td>
                        
                        <td className="px-4 py-3">
                          {task.priority ? <Badge variant="outline" className={`text-[10px] uppercase tracking-wider font-black ${getPriorityColor(task.priority)}`}>{task.priority}</Badge> : <span className="text-xs text-slate-400">—</span>}
                        </td>
                        
                        <td className="px-4 py-3">
                          {dueDateObj ? (
                            isOverdue ? (
                              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-100 text-red-700 border border-red-300 text-[10px] font-black shadow-sm ring-2 ring-red-100/50 animate-pulse">
                                <AlertCircle className="h-3 w-3 stroke-[3]" />OVERDUE: {format(dueDateObj, "MMM d")}
                              </div>
                            ) : (
                              <div className={`flex items-center gap-1.5 text-xs font-bold ${isUrgent ? 'text-red-800' : 'text-slate-600'}`}>
                                <Calendar className={`h-3.5 w-3.5 ${isUrgent ? 'text-red-500' : 'text-slate-400'}`} />{format(dueDateObj, "MMM d, yyyy")}
                              </div>
                            )
                          ) : <span className="text-xs text-slate-400 italic">No date</span>}
                        </td>
                        
                        <td className="px-4 py-3">
                          {assignees.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                              {assignees.map((name, i) => (
                                <div key={i} className={`inline-block h-7 w-7 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-black title ${(isUrgent || isOverdue) ? 'bg-red-200 text-red-900' : 'bg-blue-100 text-blue-800'}`} title={name}>{name.charAt(0).toUpperCase()}</div>
                              ))}
                            </div>
                          ) : <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${(isUrgent || isOverdue) ? 'text-red-600 bg-red-100' : 'text-slate-400 bg-slate-100'}`}>Unassigned</span>}
                        </td>

                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1 opacity-50 group-hover:opacity-100 transition-opacity">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0 text-slate-400 hover:text-slate-600 transition-colors"><span className="sr-only">Open menu</span><MoreVertical className="h-4 w-4" /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-40">
                                <DropdownMenuItem onClick={() => handleAddToCalendar(task)} className="cursor-pointer text-emerald-600 font-medium"><CalendarPlus className="h-4 w-4 mr-2" /> Calendar</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => openEditModal(task)} className="cursor-pointer text-blue-600 font-medium"><Edit2 className="h-4 w-4 mr-2" /> Edit Task</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => { if(window.confirm("Delete this task?")) deleteTaskMutation.mutate(task.id); }} className="cursor-pointer text-red-600 focus:text-red-600 font-medium"><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden flex flex-col divide-y divide-slate-100 bg-white">
              {currentItems.map(task => {
                const dueDateObj = safeParseDate(task.due_date_target || task.due_date);
                const isCompleted = normalizeStatus(task.status) === "Completed";
                const isOverdue = dueDateObj && dueDateObj < new Date() && !isCompleted;
                const isUrgent = task.priority?.toLowerCase() === "urgent" && !isCompleted;
                const isHigh = task.priority?.toLowerCase() === "high" && !isCompleted;

                let cardClass = "p-4 relative transition-colors";
                if (isCompleted) cardClass = "p-4 relative bg-slate-50 opacity-70";
                else if (isOverdue) cardClass = "p-4 relative bg-rose-50/80";
                else if (isUrgent) cardClass = "p-4 relative bg-red-50";
                else if (isHigh) cardClass = "p-4 relative bg-orange-50/50";

                return (
                  <div key={task.id} className={cardClass}>
                    {!isCompleted && (isOverdue || isUrgent) && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-red-600"></div>}
                    {!isCompleted && isHigh && !isOverdue && <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-400"></div>}

                    <div className="pl-1">
                      <div className="flex justify-between items-start mb-2">
                        <button type="button" className="flex flex-col items-start pr-2 cursor-pointer group/title focus:outline-none text-left" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setViewingTask(task); }}>
                          <div className="flex items-center gap-2">
                            {!isCompleted && isUrgent && <Flame className="h-4 w-4 text-red-600 fill-red-600 animate-bounce shrink-0" />}
                            <h3 className={`font-bold text-sm line-clamp-2 group-hover/title:text-blue-600 group-hover/title:underline ${isCompleted ? 'text-slate-500 line-through' : (isUrgent || isOverdue) ? 'text-red-900 font-extrabold' : 'text-slate-900'}`}>{task.title}</h3>
                          </div>
                          {task.description && <p className={`text-xs mt-1 line-clamp-2 group-hover/title:text-blue-600 ${(isUrgent || isOverdue) ? 'text-red-700/80 font-medium' : 'text-slate-500'}`}>{task.description}</p>}
                        </button>

                        <div className="flex items-center shrink-0">
                          <Button variant="ghost" size="icon" onClick={() => handleAddToCalendar(task)} className="h-7 w-7 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50"><CalendarPlus className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openEditModal(task)} className="h-7 w-7 text-slate-400 hover:text-blue-600 hover:bg-blue-50"><Edit2 className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => { if(window.confirm("Delete this task?")) deleteTaskMutation.mutate(task.id); }} className="h-7 w-7 text-slate-400 hover:text-red-600 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        {task.project_id && <Badge variant="outline" className={`text-[10px] uppercase tracking-wider ${(isUrgent || isOverdue) ? 'bg-white/70 text-red-800 border-red-200' : 'bg-white'}`}>{projectMap[task.project_id] || "Project"}</Badge>}
                        {task.priority && <Badge variant="outline" className={`text-[10px] uppercase tracking-wider font-black ${getPriorityColor(task.priority)}`}>{task.priority}</Badge>}
                      </div>

                      <div className="flex items-center justify-between border-t border-slate-200/60 pt-3">
                        <Select value={normalizeStatus(task.status)} onValueChange={v => updateStatusMutation.mutate({ id: task.id, status: v })}>
                          <SelectTrigger className={`w-[110px] h-8 text-xs font-bold ${isCompleted ? 'bg-green-50 text-green-700 border-green-200' : (isUrgent || isOverdue) ? 'bg-white border-red-300 text-red-900' : 'bg-white'}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUSES.map(s => <SelectItem key={s} value={s} className="text-xs font-bold">{s}</SelectItem>)}
                          </SelectContent>
                        </Select>

                        {dueDateObj ? (
                          isOverdue ? (
                            <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-red-100 text-red-700 border border-red-300 text-[10px] font-black animate-pulse"><AlertCircle className="h-3 w-3 stroke-[3]" />DUE {format(dueDateObj, "MMM d")}</div>
                          ) : (
                            <div className={`flex items-center gap-1.5 text-xs font-bold ${isUrgent ? 'text-red-800' : 'text-slate-600'}`}><Calendar className={`h-3.5 w-3.5 ${isUrgent ? 'text-red-500' : 'text-slate-400'}`} />{format(dueDateObj, "MMM d, yyyy")}</div>
                          )
                        ) : <span className="text-[10px] text-slate-400 italic">No date</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* PAGINATION */}
        {!isLoading && filteredTasks.length > 0 && (
          <div className="border-t border-slate-200 bg-slate-50 px-4 py-3 flex items-center justify-between mt-auto">
            <span className="text-xs font-medium text-slate-500 hidden sm:inline-block">
              Showing <span className="font-bold text-slate-900">{indexOfFirstItem + 1}</span> to <span className="font-bold text-slate-900">{Math.min(indexOfLastItem, filteredTasks.length)}</span> of <span className="font-bold text-slate-900">{filteredTasks.length}</span>
            </span>
            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
              <Button variant="outline" size="sm" className="h-8 bg-white font-bold" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}><ChevronLeft className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Previous</span></Button>
              <span className="text-xs font-bold text-slate-600 sm:hidden">Page {currentPage} of {totalPages || 1}</span>
              <Button variant="outline" size="sm" className="h-8 bg-white font-bold" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages || totalPages === 0}><span className="hidden sm:inline">Next</span><ChevronRight className="h-4 w-4 sm:ml-1" /></Button>
            </div>
          </div>
        )}
      </div>

      {/* VIEW FULL DETAILS DIALOG */}
      <Dialog open={!!viewingTask} onOpenChange={(val) => !val && setViewingTask(null)}>
        <DialogContent className="sm:max-w-lg w-[95vw] rounded-xl p-4 sm:p-6" aria-describedby={undefined}>
          <DialogHeader><DialogTitle className="text-xl font-black text-slate-900 leading-tight">{viewingTask?.title}</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-2">
            <div>
              <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5 block">Full Description</Label>
              <div className="text-sm font-medium text-slate-700 whitespace-pre-wrap bg-slate-50/80 p-4 rounded-xl border border-slate-200 min-h-[120px] max-h-[400px] overflow-y-auto custom-scrollbar">
                {viewingTask?.description || <span className="italic text-slate-400">No description provided.</span>}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row justify-end gap-2 pt-2 border-t border-slate-100 mt-2">
              <Button variant="outline" className="w-full sm:w-auto font-bold" onClick={() => setViewingTask(null)}>Close</Button>
              <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold" onClick={() => { openEditModal(viewingTask); setViewingTask(null); }}>
                <Edit2 className="h-4 w-4 mr-2" /> Edit Task
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* IMPORTED CREATE TASK DIALOG */}
      <CreateTaskDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        clients={clients}
        projects={projects}
        users={users}
        defaultClientId={String(clientId)}
        isLoading={handleCreateSubmit.isPending}
        onSubmit={(payload) => handleCreateSubmit.mutate(payload)}
      />

      {/* INLINE EDIT TASK DIALOG */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent aria-describedby={undefined} className="sm:max-w-lg w-[95vw] rounded-xl p-4 sm:p-6 bg-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-black text-slate-900">Edit Task</DialogTitle>
          </DialogHeader>

          <form onSubmit={(e) => { e.preventDefault(); updateTaskMutation.mutate(editForm); }} className="space-y-4 pt-2">
            
            <div className="space-y-2">
              <Label htmlFor="edit-title" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Task Title *</Label>
              <Input 
                id="edit-title"
                value={editForm.title} 
                onChange={e => setEditForm({...editForm, title: e.target.value})} 
                placeholder="Enter task title" 
                className="font-bold border-slate-200" 
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-description" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Description</Label>
              <Textarea
                id="edit-description"
                placeholder="Task description (optional)"
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                className="h-24 resize-none font-medium border-slate-200"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Project</Label>
                <Select value={projects?.some(p => String(p.id) === String(editForm.project_id)) ? String(editForm.project_id) : "none"} onValueChange={(v) => setEditForm({ ...editForm, project_id: v })}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select Project" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Project</SelectItem>
                    {projects?.map((p) => (
                      <SelectItem key={String(p.id)} value={String(p.id)}>{p.name || `Project #${p.project_number}`}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider">Assignee</Label>
                <Select value={users?.some(u => String(u.id) === String(editForm.assigned_to)) ? String(editForm.assigned_to) : "none"} onValueChange={(v) => setEditForm({ ...editForm, assigned_to: v })}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Unassigned" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Unassigned</SelectItem>
                    {users?.map((u) => (
                      <SelectItem key={String(u.id)} value={String(u.id)}>{u.full_name || u.email || "Unknown User"}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

<div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Project</Label>
                <Select value={projects?.some(p => String(p.id) === String(editForm.project_id)) ? String(editForm.project_id) : "none"} onValueChange={(v) => setEditForm({ ...editForm, project_id: v })}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select Project" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Project</SelectItem>
                    {projects?.map((p) => (
                      <SelectItem key={String(p.id)} value={String(p.id)}>{p.name || `Project #${p.project_number}`}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Assignee</Label>
                <Select value={users?.some(u => String(u.id) === String(editForm.assigned_to)) ? String(editForm.assigned_to) : "none"} onValueChange={(v) => setEditForm({ ...editForm, assigned_to: v })}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Unassigned" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Unassigned</SelectItem>
                    {users?.map((u) => (
                      <SelectItem key={String(u.id)} value={String(u.id)}>{u.full_name || u.email || "Unknown User"}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Priority</Label>
                <Select value={editForm.priority || "Medium"} onValueChange={v => setEditForm({...editForm, priority: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Low", "Medium", "High", "Urgent"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Status</Label>
                <Select value={editForm.status || "To Do"} onValueChange={v => setEditForm({...editForm, status: v})}>
                  <SelectTrigger className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["To Do", "Doing", "Blocked", "Done", "Pending", "Active", "Under Review", "Completed"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Due Date</Label>
                <Input
                  type="date"
                  value={editForm.due_date_target || ""}
                  onChange={(e) => setEditForm({ ...editForm, due_date_target: e.target.value })}
                  className="font-medium border-slate-200 text-sm block w-full"
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Est. Hours</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.5"
                  placeholder="e.g. 2.5"
                  value={editForm.estimated_hours || ""}
                  onChange={(e) => setEditForm({ ...editForm, estimated_hours: e.target.value })}
                  className="font-medium border-slate-200 text-sm"
                />
              </div>
            </div>

            <DialogFooter className="pt-4 border-t border-slate-100 flex-col sm:flex-row gap-2 sm:gap-0 mt-2">
              <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)} className="w-full sm:w-auto font-bold order-2 sm:order-1">Cancel</Button>
              <Button type="submit" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md order-1 sm:order-2" disabled={!editForm.title || updateTaskMutation.isPending}>
                {updateTaskMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}