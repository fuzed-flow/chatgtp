import React, { useState, useEffect, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/api/supabaseClient"; 
import { useAuth } from "@/lib/AuthContext"; 
import { Link, useNavigate } from "react-router-dom"; 
import { Plus, Trash2, FileText, Eye, LayoutTemplate, Send, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PageHeader from "../components/shared/PageHeader";
import CreateQuoteFromTemplateDialog from "../components/shared/CreateQuoteFromTemplateDialog";
import DataTable from "../components/shared/DataTable";
import FilterBar from "../components/shared/FilterBar";
import ActionMenu from "../components/shared/ActionMenu";
import StatusBadge from "../components/shared/StatusBadge";
import ViewToggle from "../components/shared/ViewToggle";
import SendQuoteEmailDialog from "../components/quotes/SendQuoteEmailDialog";
import DuplicateQuoteDialog from "../components/quotes/DuplicateQuoteDialog";
import { format } from "date-fns";
import { toast } from "sonner"; 

export default function Quotes() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;

  const [view, setView] = useState(() => localStorage.getItem("quotesView") || "list");
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [filters, setFilters] = useState({});
  const navigate = useNavigate();
  const [sortOrder, setSortOrder] = useState("default");
  
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [selectedQuoteForSend, setSelectedQuoteForSend] = useState(null);
  const [duplicateDialogOpen, setDuplicateDialogOpen] = useState(false);
  const [selectedQuoteForDuplicate, setSelectedQuoteForDuplicate] = useState(null);
  const queryClient = useQueryClient();

  const handleViewChange = (newView) => {
    setView(newView);
    localStorage.setItem("quotesView", newView);
  };

  // 1. FETCH QUOTES FROM SUPABASE
  const { data: quotes = [] } = useQuery({ 
    queryKey: ["quotes", companyId], 
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quotes")
        .select("*")
        .eq("company_id", companyId)
        .eq("is_template", false)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    } 
  });

  // 2. FETCH CLIENTS FROM SUPABASE
  const { data: clients = [] } = useQuery({ 
    queryKey: ["clients", companyId], 
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("id, name, email") // <-- ADD EMAIL HERE
        .eq("company_id", companyId);
      if (error) throw error;
      return data;
    } 
  });

  // 3. SUPABASE DELETE MUTATION
  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from("quotes").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["quotes", companyId] });
      toast.success("Quote deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete quote: " + error.message);
    }
  });

  // --- PERFORMANCE & SEARCH FIXES ---
  
  // Memoize the client map to hold both name and email
  const clientDataMap = useMemo(() => {
    return Object.fromEntries(clients.map(c => [c.id, { name: c.name, email: c.email }]));
  }, [clients]);

  // Memoize filtering, sorting, and injecting client_name/email into the objects
  const filteredAndMappedQuotes = useMemo(() => {
    return quotes
      .filter(q => {
        if (filters.status && q.status !== filters.status) return false;
        return true;
      })
      .map(q => ({
        ...q,
        client_name: clientDataMap[q.client_id]?.name || "—",
        client_email: clientDataMap[q.client_id]?.email || "" // <-- INJECT EMAIL HERE
      }))
      .sort((a, b) => {
        if (sortOrder === "a-z") return (a.title || "").localeCompare(b.title || "");
        if (sortOrder === "z-a") return (b.title || "").localeCompare(a.title || "");
        return 0; 
      });
  }, [quotes, filters.status, sortOrder, clientDataMap]);

  const columns = [
    { key: "quote_number", label: "Quote #", width: "110px" },
    {
      key: "title",
      label: "Title",
      width: "150px",
      render: (title, q) => (
        <Link to={`/QuoteBuilder?id=${q.id}`} className="text-slate-700 hover:text-amber-600 font-medium">
          {title}
        </Link>
      )
    },
    // Using the newly injected client_name field
    { key: "client_name", label: "Client", width: "150px" },
    { key: "site_address", label: "Site Address", width: "180px", render: (addr) => addr || "—" },
    { key: "total", label: "Total", width: "100px", render: (total) => `$${(Number(total) || 0).toLocaleString()}` },
    { key: "status", label: "Status", width: "100px", render: (status) => <StatusBadge status={status} /> },
    { key: "issue_date", label: "Date", width: "120px", render: (date) => date ? format(new Date(date), "MMM d, yyyy") : "—" },
  ];

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Quotes"
        description={`${filteredAndMappedQuotes.length} active quotes`}
        actions={
          <div className="flex flex-wrap gap-2">
            <CreateQuoteFromTemplateDialog>
              <Button variant="outline" size="sm" className="gap-2">
                <LayoutTemplate className="h-4 w-4" /> <span className="hidden sm:inline">From Template</span>
              </Button>
            </CreateQuoteFromTemplateDialog>
            <Link to="/QuoteBuilder">
              <Button size="sm" className="bg-slate-900 hover:bg-slate-800"><Plus className="h-4 w-4 mr-1" /> New Quote</Button>
            </Link>
          </div>
        }
      />

      <div className="mb-4 flex flex-col sm:flex-row justify-between gap-3">
        <div className="flex flex-wrap gap-2 items-center">
          <FilterBar
            filters={[
              { key: "status", label: "Status", type: "select", options: ["Draft", "Sent", "Approved", "Declined", "Expired"].map(s => ({ label: s, value: s })) },
            ]}
            onFiltersChange={setFilters}
          />
          <Select value={sortOrder} onValueChange={setSortOrder}>
            <SelectTrigger className="w-[150px] sm:w-[180px]">
              <SelectValue placeholder="Sort by..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default (Newest)</SelectItem>
              <SelectItem value="a-z">A-Z</SelectItem>
              <SelectItem value="z-a">Z-A</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {!isMobile && <ViewToggle view={view} onViewChange={handleViewChange} />}
      </div>

      {view === "list" && !isMobile ? (
        <DataTable
          columns={columns}
          data={filteredAndMappedQuotes}
          searchableFields={["quote_number", "title", "client_name", "site_address", "total", "status", "issue_date"]}
          emptyMessage="No quotes found"
          onRowClick={(quote) => navigate(`/QuoteBuilder?id=${quote.id}`)}
          actions={(quote) => (
            <ActionMenu
              actions={[
                { label: "Send", icon: Send, onClick: () => { setSelectedQuoteForSend(quote); setSendDialogOpen(true); } },
                { label: "Duplicate", icon: Copy, onClick: () => { setSelectedQuoteForDuplicate(quote); setDuplicateDialogOpen(true); } },
                { label: "Delete", icon: Trash2, destructive: true, onClick: () => deleteMutation.mutate(quote.id) },
              ]}
            />
          )}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAndMappedQuotes.length === 0 && (
            <div className="col-span-full py-8 text-center text-slate-500">No quotes found</div>
          )}
          {filteredAndMappedQuotes.map(quote => (
            <Card 
              key={quote.id} 
              className="cursor-pointer hover:shadow-lg transition-all"
              onClick={() => navigate(`/QuoteBuilder?id=${quote.id}`)}
            >
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 pr-2">
                    <h3 className="font-semibold text-lg text-slate-900 mb-1">{quote.title}</h3>
                    <div className="text-sm text-slate-500 mb-2">{quote.quote_number}</div>
                    <StatusBadge status={quote.status} />
                  </div>
                  <ActionMenu
                    actions={[
                      { label: "Send", icon: Send, onClick: (e) => { e.stopPropagation(); setSelectedQuoteForSend(quote); setSendDialogOpen(true); } },
                      { label: "Duplicate", icon: Copy, onClick: (e) => { e.stopPropagation(); setSelectedQuoteForDuplicate(quote); setDuplicateDialogOpen(true); } },
                      { label: "Delete", icon: Trash2, destructive: true, onClick: (e) => { e.stopPropagation(); deleteMutation.mutate(quote.id); } },
                    ]}
                  />
                </div>
                <div className="space-y-2 mt-4 pt-4 border-t border-slate-100">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Client:</span>
                    <span className="font-medium text-slate-900 text-right">{quote.client_name}</span>
                  </div>
                  {quote.site_address && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Site:</span>
                      <span className="font-medium text-slate-900 text-right max-w-[60%] truncate">{quote.site_address}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Date:</span>
                    <span className="font-medium text-slate-900">{quote.issue_date ? format(new Date(quote.issue_date), "MMM d, yyyy") : "—"}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Total:</span>
                    <span className="font-medium text-slate-900">${(Number(quote.total) || 0).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <SendQuoteEmailDialog 
        open={sendDialogOpen} 
        onOpenChange={setSendDialogOpen} 
        quoteId={selectedQuoteForSend?.id}
        quoteName={selectedQuoteForSend?.title || `Quote ${selectedQuoteForSend?.quote_number}`}
        clientName={selectedQuoteForSend?.client_name || ""} // <-- UPDATED
        clientEmail={selectedQuoteForSend?.client_email || ""} // <-- UPDATED
        onSuccess={() => {
          queryClient.invalidateQueries(["quotes"]);
        }}
      />

      {selectedQuoteForDuplicate && (
        <DuplicateQuoteDialog
          open={duplicateDialogOpen}
          onOpenChange={setDuplicateDialogOpen}
          quote={selectedQuoteForDuplicate}
          onSuccess={() => queryClient.invalidateQueries({ queryKey: ["quotes", companyId] })}
        />
      )}
    </div>
  );
}