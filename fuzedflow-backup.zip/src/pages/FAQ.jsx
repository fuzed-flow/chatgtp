import React from "react";
import { FileQuestion, ChevronDown } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function FAQ() {
  const faqs = [
    { q: "How do I invite my team members?", a: "Go to your Company Settings, click on the Team tab, and click 'Invite Member'. They will receive an email to set up their password." },
    { q: "Can clients approve quotes digitally?", a: "Yes! When you email a quote to a client, they receive a secure link to view the breakdown and sign digitally." },
    { q: "How do I change my dashboard layout?", a: "Click the 'Customize' button with the gear icon on the top right of your dashboard to toggle widgets on and off." }
  ];

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-black text-slate-900 flex items-center gap-3">
          <FileQuestion className="h-8 w-8 text-emerald-500" /> Frequently Asked Questions
        </h1>
        <p className="text-slate-500 font-medium mt-2">Find answers to common questions about using the platform.</p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, i) => (
          <Card key={i} className="p-5 border-slate-200">
            <h3 className="font-black text-slate-900 text-lg">{faq.q}</h3>
            <p className="text-slate-600 mt-2 leading-relaxed font-medium">{faq.a}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}