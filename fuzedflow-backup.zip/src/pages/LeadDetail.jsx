import React, { useState } from "react";
import { supabase } from "@/api/supabaseClient"; 
import { useAuth } from "@/lib/AuthContext"; 
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Mail, Phone, ArrowLeft, DollarSign, Calendar, Pencil, UserCheck } from "lucide-react";
import LeadFilesSection from "../components/leads/LeadFilesSection";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import StatusBadge from "../components/shared/StatusBadge";
import NotesFeed from "../components/shared/NotesFeed";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import AddressAutocomplete from "../components/shared/AddressAutocomplete";

export default function LeadDetail() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;

  const params = new URLSearchParams(window.location.search);
  const leadId = params.get("id");
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [formData, setFormData] = useState({});

  // 1. FETCH LEAD FROM SUPABASE
  const { data: lead } = useQuery({
    queryKey: ["lead", leadId],
    enabled: !!leadId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .eq("id", leadId)
        .single();
      if (error) throw error;
      return data;
    },
  });

  // 2. FETCH USERS FROM SUPABASE PROFILES
  const { data: users = [] } = useQuery({
    queryKey: ["users", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("company_id", companyId);
      if (error) throw error;
      return data;
    },
  });

  // 3. UPDATE MUTATION
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const { error } = await supabase.from("leads").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead", leadId] });
      queryClient.invalidateQueries({ queryKey: ["leads", companyId] }); 
      setEditDialogOpen(false);
      toast.success("Lead updated");
    },
  });

 // 4. CONVERT TO CLIENT MUTATION
  const convertToClientMutation = useMutation({
    mutationFn: async (leadData) => {
      // Create Client
      const { data: clientRef, error: clientError } = await supabase.from("clients").insert([{
        company_id: companyId,
        name: leadData.contact_name || "Unnamed Client",
        primary_contact_name: leadData.contact_name || "",
        email: leadData.contact_email || "",
        phone: leadData.contact_phone || "",
        site_address: leadData.site_address || "",
        billing_address: leadData.site_address || "",
        notes: [leadData.description, leadData.notes].filter(Boolean).join("\n\n") || "",
        tags: [leadData.source].filter(Boolean),
        type: "Residential"
      }]).select().single();
      
      if (clientError) throw clientError;

      // Mark Lead as Won
      const { error: leadError } = await supabase.from("leads").update({ pipeline_stage: "Won" }).eq("id", leadId);
      if (leadError) throw leadError;

      // ⚡ COPY ALL NOTES OVER TO THE NEW CLIENT
      const { data: leadNotes } = await supabase
        .from("notes")
        .select("*")
        .eq("related_type", "Lead")
        .eq("related_id", leadId);

      if (leadNotes && leadNotes.length > 0) {
        const copiedNotes = leadNotes.map(note => {
          const { id, created_at, updated_at, ...noteDataToCopy } = note; 
          return {
            ...noteDataToCopy,
            related_type: "Client",
            related_id: clientRef.id
          };
        });

        const { error: insertNotesError } = await supabase
          .from("notes")
          .insert(copiedNotes);

        if (insertNotesError) {
          console.error("Failed to copy notes over:", insertNotesError.message);
        }
      }

      // Return the new client data so onSuccess can use its ID
      return clientRef;
    },
    // ⚡ ADDED 'newClient' ARGUMENT TO CATCH THE RETURNED CLIENT FROM ABOVE
    onSuccess: (newClient) => {
      queryClient.invalidateQueries({ queryKey: ["notes"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["all_tasks"] });
      queryClient.invalidateQueries({ queryKey: ["project_daily_logs"] });
      
      toast.success("Lead successfully converted to Client!");
      
      // ⚡ IMMEDIATELY NAVIGATE TO THE NEW CLIENT'S PROFILE
      navigate(`/ClientDetail?id=${newClient.id}`);
    },
  });

  const handleEdit = () => {
    const nameParts = lead.contact_name ? lead.contact_name.split(" ") : ["", ""];
    const firstName = nameParts[0] || "";
    const surname = nameParts.slice(1).join(" ") || "";
    
    setFormData({
      first_name: firstName,
      surname: surname,
      contact_email: lead.contact_email || "",
      contact_phone: lead.contact_phone || "",
      source: lead.source || "Referral",
      pipeline_stage: lead.pipeline_stage || "New",
      value_estimate: lead.value_estimate || "",
      priority: lead.priority || "Medium",
      next_follow_up_date: lead.next_follow_up_date || "",
      assigned_to: lead.assigned_to || "",
      site_address: lead.site_address || "",
      description: lead.description || "",
      notes: lead.notes || ""
    });
    setEditDialogOpen(true);
  };

  const handleSave = () => {
    const fullName = `${formData.first_name} ${formData.surname}`.trim();
    const { first_name, surname, ...rest } = formData;
    const data = { ...rest, contact_name: fullName };
    
    if (data.value_estimate !== "" && data.value_estimate !== null && data.value_estimate !== undefined) {
      data.value_estimate = parseFloat(data.value_estimate);
    } else {
      data.value_estimate = null;
    }
    
    if (!data.next_follow_up_date) data.next_follow_up_date = null;

    updateMutation.mutate({ id: leadId, data });
  };

  if (!lead) return <div className="p-6 text-center text-slate-500 font-medium">Loading lead details...</div>;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto pb-20">
      
      {/* ⚡ Breadcrumb */}
      <Link to="/LeadTracker" className="inline-flex items-center gap-1 text-sm font-bold text-slate-500 hover:text-slate-800 mb-4 transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back to Leads
      </Link>

      {/* ⚡ HEADER CARD */}
      <Card className="p-5 sm:p-6 mb-6 border-slate-200/80 shadow-sm bg-white">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight leading-tight">{lead.contact_name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <StatusBadge status={lead.pipeline_stage} />
              <StatusBadge status={lead.priority} />
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto mt-2 sm:mt-0">
            <Button 
              onClick={() => convertToClientMutation.mutate(lead)} 
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold w-full sm:w-auto shadow-sm"
              disabled={convertToClientMutation.isPending}
            >
              <UserCheck className="h-4 w-4 mr-2" /> {convertToClientMutation.isPending ? "Converting..." : "Convert to Client"}
            </Button>
            <Button onClick={handleEdit} variant="outline" className="w-full sm:w-auto font-bold text-slate-700 border-slate-300">
              <Pencil className="h-4 w-4 mr-2" /> Edit
            </Button>
          </div>
        </div>

        {/* ⚡ MAIN DATA GRID - Mobile: 1 col, Tablet: 2 cols, Desktop: 4 cols */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-5 border-t border-slate-100">
          {lead.contact_email && (
            <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
              <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm shrink-0">
                <Mail className="h-4 w-4 text-blue-500" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">Email</p>
                <p className="text-sm font-semibold text-slate-800 truncate" title={lead.contact_email}>{lead.contact_email}</p>
              </div>
            </div>
          )}
          
          {lead.contact_phone && (
            <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
              <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm shrink-0">
                <Phone className="h-4 w-4 text-emerald-500" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">Phone</p>
                <p className="text-sm font-semibold text-slate-800">{lead.contact_phone}</p>
              </div>
            </div>
          )}
          
          {lead.value_estimate && (
            <div className="flex items-start gap-3 bg-amber-50/50 p-3 rounded-xl border border-amber-100/50">
              <div className="bg-white p-2 rounded-lg border border-amber-200 shadow-sm shrink-0">
                <DollarSign className="h-4 w-4 text-amber-500" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-amber-600/70 uppercase tracking-wider mb-0.5">Est. Value</p>
                <p className="text-sm font-black text-amber-700">${Number(lead.value_estimate).toLocaleString()}</p>
              </div>
            </div>
          )}
          
          {lead.next_follow_up_date && (
            <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
              <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm shrink-0">
                <Calendar className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">Follow Up</p>
                <p className="text-sm font-semibold text-slate-800">{format(new Date(lead.next_follow_up_date), "MMM d, yyyy")}</p>
              </div>
            </div>
          )}
        </div>

        {/* ⚡ SECONDARY DATA GRID - Stacks vertically on mobile */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6 pt-6 border-t border-slate-100">
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Lead Source</p>
            <p className="text-sm font-medium text-slate-700 bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-lg inline-block">{lead.source || "—"}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Assigned To</p>
            <p className="text-sm font-medium text-slate-700 bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-lg inline-block">{lead.assigned_to || "Unassigned"}</p>
          </div>
          {lead.site_address && (
            <div className="sm:col-span-2 lg:col-span-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Site Address</p>
              <p className="text-sm font-medium text-slate-700 bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-lg">{lead.site_address}</p>
            </div>
          )}
        </div>

        {lead.description && (
          <div className="mt-6 pt-6 border-t border-slate-100">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">Description</p>
            <p className="text-sm font-medium text-slate-700 leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-slate-100">{lead.description}</p>
          </div>
        )}

        {lead.notes && (
          <div className="mt-4">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">Notes</p>
            <p className="text-sm font-medium text-slate-700 whitespace-pre-wrap leading-relaxed bg-amber-50/30 p-4 rounded-xl border border-amber-100/50">{lead.notes}</p>
          </div>
        )}

        <div className="mt-6 pt-6 border-t border-slate-100 text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center sm:text-left">
          Lead created {lead.created_at ? `on ${format(new Date(lead.created_at), "MMM d, yyyy")}` : ""}
        </div>
      </Card>

      {/* ⚡ FILES & NOTES SECTIONS */}
      <div className="space-y-6">
        <LeadFilesSection
          lead={lead}
          onUpdate={async (data) => {
            await supabase.from("leads").update(data).eq("id", leadId);
            queryClient.invalidateQueries({ queryKey: ["lead", leadId] });
          }}
        />

        <Card className="p-0 sm:p-2 shadow-sm border-slate-200/80 bg-white overflow-hidden rounded-xl">
          <NotesFeed 
      relatedType="Lead" 
      relatedId={lead?.id}
      clientId={lead?.client_id} 
    />
        </Card>
      </div>

      {/* ⚡ EDIT DIALOG - Fully Responsive */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto w-[95vw] rounded-xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-black">Edit Lead</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">First Name *</Label>
                <Input value={formData.first_name} onChange={e => setFormData({...formData, first_name: e.target.value})} className="font-medium h-10" />
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Surname *</Label>
                <Input value={formData.surname} onChange={e => setFormData({...formData, surname: e.target.value})} className="font-medium h-10" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Email</Label>
                <Input type="email" value={formData.contact_email} onChange={e => setFormData({...formData, contact_email: e.target.value})} className="font-medium h-10" />
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Phone</Label>
                <Input value={formData.contact_phone} onChange={e => setFormData({...formData, contact_phone: e.target.value})} className="font-medium h-10" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Lead Source</Label>
                <Select value={formData.source} onValueChange={v => setFormData({...formData, source: v})}>
                  <SelectTrigger className="h-10 font-medium"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Facebook", "Instagram", "Google", "Referral", "Website", "Kijiji", "Other"].map(s => (
                      <SelectItem key={s} value={s} className="font-medium">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Priority Level</Label>
                <Select value={formData.priority} onValueChange={v => setFormData({...formData, priority: v})}>
                  <SelectTrigger className="h-10 font-medium"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Low", "Medium", "High", "Urgent"].map(p => (
                      <SelectItem key={p} value={p} className="font-medium">{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Pipeline Stage</Label>
              <Select value={formData.pipeline_stage} onValueChange={v => setFormData({...formData, pipeline_stage: v})}>
                <SelectTrigger className="h-10 font-medium bg-slate-50 border-slate-200"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["New", "Contacted", "Booked Visit", "Quoted", "Negotiation", "Won", "Lost"].map(s => (
                    <SelectItem key={s} value={s} className="font-bold">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Value Estimate ($)</Label>
                <Input type="number" value={formData.value_estimate} onChange={e => setFormData({...formData, value_estimate: e.target.value})} className="font-medium h-10" />
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Next Follow Up Date</Label>
                <Input type="date" value={formData.next_follow_up_date || ""} onChange={e => setFormData({...formData, next_follow_up_date: e.target.value})} className="font-medium h-10 block w-full" />
              </div>
            </div>

            <div>
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Assign Team Member</Label>
              <Select value={formData.assigned_to} onValueChange={v => setFormData({...formData, assigned_to: v})}>
                <SelectTrigger className="h-10 font-medium"><SelectValue placeholder="Select team member" /></SelectTrigger>
                <SelectContent>
                  {users.map(user => (
                    <SelectItem key={user.id} value={user.full_name || user.name || "Unknown User"} className="font-medium">
                      {user.full_name || user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Site / Project Address</Label>
              <AddressAutocomplete
                value={formData.site_address || ""}
                onChange={v => setFormData({...formData, site_address: v})}
                placeholder="Start typing an address..."
              />
            </div>

            <div>
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Description</Label>
              <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} rows={3} className="font-medium bg-slate-50" />
            </div>

            <div>
              <Label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Internal Notes</Label>
              <Textarea value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} rows={3} className="font-medium bg-slate-50" />
            </div>

            <div className="flex flex-col sm:flex-row justify-end gap-2 pt-4 border-t border-slate-100">
              <Button variant="outline" onClick={() => setEditDialogOpen(false)} className="w-full sm:w-auto font-bold border-slate-300 order-2 sm:order-1">Cancel</Button>
              <Button onClick={handleSave} disabled={!formData.first_name || !formData.surname || updateMutation.isPending} className="w-full sm:w-auto bg-slate-900 hover:bg-slate-800 font-bold order-1 sm:order-2 shadow-md">
                {updateMutation.isPending ? "Saving..." : "Update Lead"}
              </Button>
            </div>
            
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}