import React, { useState } from "react";
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Bell, Check, Trash2, Clock, AlertCircle, Loader2, MessageSquare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const NOTIFICATION_ICONS = {
  LeadFollowUp: Clock,
  QuoteExpiring: AlertCircle,
  QuoteOpened: Check,
  InvoiceOverdue: AlertCircle,
  ProjectUpdate: AlertCircle,
  ApprovalSigned: Check,
  ChangeOrderApproved: Check,
  System: AlertCircle,
  quote_change_request: AlertCircle,
  NewSmsReceived: MessageSquare
};

export default function EnhancedNotificationCenter() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile } = useAuth();
  const companyId = profile?.company_id;
  const [open, setOpen] = useState(false);

  // 1. FETCH NOTIFICATIONS FROM SUPABASE
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["notifications", profile?.id],
    enabled: !!profile?.id && !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .eq("company_id", companyId)
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(50); // Keep it snappy
        
      if (error) throw error;
      return data || [];
    },
  });

  // 2. MARK AS READ MUTATION
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId) => {
      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("id", notificationId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });

  // 3. MARK ALL AS READ MUTATION
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("user_id", profile.id)
        .eq("is_read", false);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });

  // 4. DELETE NOTIFICATION MUTATION
  const deleteNotificationMutation = useMutation({
    mutationFn: async (notificationId) => {
      const { error } = await supabase.from("notifications").delete().eq("id", notificationId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });

  const handleActionClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate(notification.id);
    }
    if (notification.action_url) {
      navigate(notification.action_url);
    }
    setOpen(false);
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="relative p-2 rounded-lg hover:bg-slate-800 transition-all group outline-none">
          <Bell className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center font-black shadow-sm ring-2 ring-slate-900">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md bg-slate-50 border-slate-200 shadow-xl p-0 overflow-hidden" aria-describedby={undefined}>
        <DialogHeader className="p-4 border-b border-slate-200 bg-white flex flex-row items-center justify-between">
          <DialogTitle className="font-black text-lg text-slate-900 flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-500" /> Notifications
          </DialogTitle>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={markAllAsReadMutation.isPending}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:bg-blue-50 h-8"
            >
              {markAllAsReadMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Check className="h-3 w-3 mr-1" />}
              Mark all read
            </Button>
          )}
        </DialogHeader>

        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-2">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-10">
              <Loader2 className="h-8 w-8 text-blue-500 animate-spin mb-2" />
              <p className="text-xs font-bold text-slate-400">Loading notifications...</p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="text-center py-10">
              <div className="h-12 w-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Bell className="h-5 w-5 text-slate-300" />
              </div>
              <p className="text-sm font-bold text-slate-500">You're all caught up!</p>
              <p className="text-xs text-slate-400 mt-1">No new notifications right now.</p>
            </div>
          ) : (
            notifications.map((notification) => {
              const Icon = NOTIFICATION_ICONS[notification.type] || AlertCircle;
              return (
                <div
                  key={notification.id}
                  className={`p-3 rounded-xl border transition-all ${
                    notification.is_read 
                      ? "bg-white border-slate-200 shadow-sm opacity-70" 
                      : "bg-blue-50/50 border-blue-200 shadow-sm"
                  }`}
                >
                  <div className="flex gap-3">
                    <div className={`mt-0.5 h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${notification.is_read ? "bg-slate-100" : "bg-blue-100"}`}>
                      <Icon className={`h-4 w-4 ${notification.is_read ? "text-slate-400" : "text-blue-600"}`} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h4 className={`font-bold text-sm truncate ${notification.is_read ? "text-slate-700" : "text-slate-900"}`}>
                          {notification.title}
                        </h4>
                        <span className="text-[10px] font-bold text-slate-400 whitespace-nowrap shrink-0">
                          {notification.created_at ? formatDistanceToNow(new Date(notification.created_at), { addSuffix: true }) : ''}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed mb-3 line-clamp-2">{notification.body}</p>
                      
                      <div className="flex items-center gap-2">
                        {notification.action_url && (
                          <Button
                            size="sm"
                            onClick={() => handleActionClick(notification)}
                            className={`h-7 px-3 text-[10px] font-black uppercase tracking-wider ${notification.is_read ? "bg-slate-200 hover:bg-slate-300 text-slate-700" : "bg-blue-600 hover:bg-blue-700 text-white shadow-sm"}`}
                          >
                            View Details
                          </Button>
                        )}
                        {!notification.is_read && (
                          <Button
                            size="sm" variant="outline"
                            onClick={() => markAsReadMutation.mutate(notification.id)}
                            className="h-7 px-2 text-[10px] font-bold border-slate-300 text-slate-600"
                          >
                            Mark Read
                          </Button>
                        )}
                        <Button
                          size="icon" variant="ghost"
                          onClick={() => deleteNotificationMutation.mutate(notification.id)}
                          className="h-7 w-7 ml-auto text-slate-400 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}