import React, { useRef, useState } from "react";
import { supabase } from "@/api/supabaseClient"; // NEW: Using Supabase!
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Trash2, FileText, Image, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function LeadFilesSection({ lead, onUpdate }) {
  const photoInputRef = useRef();
  const docInputRef = useRef();
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingDoc, setUploadingDoc] = useState(false);

  // Safely parse JSONB arrays or fallback to empty arrays
  const photos = lead?.photos || [];
  const documents = lead?.documents || [];

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploadingPhoto(true);
    
    try {
      const uploadedUrls = [];
      for (const file of files) {
        // Create a unique file name using the lead ID and a timestamp
        const fileExt = file.name.split('.').pop();
        const fileName = `${lead.id}/photo-${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

        // Upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
          .from('lead_files')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('lead_files')
          .getPublicUrl(fileName);

        uploadedUrls.push(publicUrl);
      }

      // Update the Lead record
      const updatedPhotos = [...photos, ...uploadedUrls];
      await onUpdate({ photos: updatedPhotos });
      toast.success("Photo(s) uploaded successfully");
      
    } catch (error) {
      toast.error("Failed to upload photos: " + error.message);
    } finally {
      setUploadingPhoto(false);
      e.target.value = "";
    }
  };

  const handleDocUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploadingDoc(true);
    
    try {
      const uploadedDocs = [];
      for (const file of files) {
        // Create a unique file name
        const fileExt = file.name.split('.').pop();
        const fileName = `${lead.id}/doc-${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

        // Upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
          .from('lead_files')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('lead_files')
          .getPublicUrl(fileName);

        uploadedDocs.push({ file_url: publicUrl, file_name: file.name });
      }

      // Update the Lead record
      const updatedDocs = [...documents, ...uploadedDocs];
      await onUpdate({ documents: updatedDocs });
      toast.success("Document(s) uploaded successfully");
      
    } catch (error) {
      toast.error("Failed to upload documents: " + error.message);
    } finally {
      setUploadingDoc(false);
      e.target.value = "";
    }
  };

  const removePhoto = async (idx) => {
    const updated = photos.filter((_, i) => i !== idx);
    await onUpdate({ photos: updated });
    toast.success("Photo removed");
  };

  const removeDoc = async (idx) => {
    const updated = documents.filter((_, i) => i !== idx);
    await onUpdate({ documents: updated });
    toast.success("Document removed");
  };

  return (
    <Card className="p-6 mt-6 border-slate-200/80 shadow-sm">
      <h2 className="text-base font-semibold text-slate-800 mb-4">Files & Photos</h2>

      {/* Photos */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-slate-700">Photos</h3>
          <Button size="sm" variant="outline" onClick={() => photoInputRef.current?.click()} disabled={uploadingPhoto}>
            {uploadingPhoto ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Image className="h-4 w-4 mr-1" />}
            Upload Photo
          </Button>
          <input ref={photoInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
        </div>
        {photos.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {photos.map((url, idx) => (
              <div key={idx} className="relative group rounded-lg overflow-hidden border border-slate-200 shadow-sm">
                <img src={url} alt="" className="w-full h-28 object-cover" />
                <button
                  onClick={() => removePhoto(idx)}
                  className="absolute top-1 right-1 bg-red-600/90 hover:bg-red-600 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-400 italic bg-slate-50 p-4 rounded-lg border border-dashed border-slate-200 text-center">No photos uploaded yet.</p>
        )}
      </div>

      {/* Documents */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-slate-700">Documents</h3>
          <Button size="sm" variant="outline" onClick={() => docInputRef.current?.click()} disabled={uploadingDoc}>
            {uploadingDoc ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
            Upload Document
          </Button>
          <input ref={docInputRef} type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt" multiple className="hidden" onChange={handleDocUpload} />
        </div>
        {documents.length > 0 ? (
          <div className="space-y-2">
            {documents.map((doc, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-lg border border-slate-200 shadow-sm hover:border-amber-300 transition-colors">
                <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-slate-700 hover:text-amber-600 font-medium">
                  <FileText className="h-4 w-4 text-amber-500" />
                  {doc.file_name}
                </a>
                <Button size="icon" variant="ghost" onClick={() => removeDoc(idx)} className="text-slate-400 hover:bg-red-50 hover:text-red-600 h-8 w-8">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-400 italic bg-slate-50 p-4 rounded-lg border border-dashed border-slate-200 text-center">No documents uploaded yet.</p>
        )}
      </div>
    </Card>
  );
}