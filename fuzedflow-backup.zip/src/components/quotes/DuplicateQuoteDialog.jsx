import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
// 1. REPLACED FIREBASE WITH SUPABASE
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy, Loader2 } from "lucide-react";

export default function DuplicateQuoteDialog({ open, onOpenChange, quote, onSuccess }) {
  const [selectedClientId, setSelectedClientId] = useState("");
  const queryClient = useQueryClient();
  const { profile } = useAuth();
  const companyId = profile?.company_id;

  // 2. FETCH CLIENTS FROM SUPABASE
  const { data: clients = [] } = useQuery({
    queryKey: ["clients", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("*")
        .eq("company_id", companyId)
        .order("name", { ascending: true });
      if (error) throw error;
      return data || [];
    },
  });

  // 3. SUPABASE RELATIONAL DUPLICATION MUTATION
  const duplicateMutation = useMutation({
    mutationFn: async (newClientId) => {
      if (!newClientId) throw new Error("Please select a client");

      // A. Fetch full original quote data
      const { data: fullQuote, error: quoteErr } = await supabase
        .from("quotes")
        .select("*")
        .eq("id", quote.id)
        .single();
        
      if (quoteErr || !fullQuote) throw new Error("Original quote not found in database.");

      // B. Fetch related data (Phases, Items, Schedules)
      const { data: phases } = await supabase.from("quote_phases").select("*").eq("quote_id", quote.id);
      const { data: items } = await supabase.from("quote_line_items").select("*").eq("quote_id", quote.id);
      const { data: scheduleItems } = await supabase.from("quote_payment_schedule").select("*").eq("quote_id", quote.id);

      const selectedClient = clients.find(c => c.id === newClientId);
      let newQuoteNumber = `QT-${Date.now().toString().slice(-4)}`; // Generate new standard number

      // C. Strip system fields from original quote and prep new quote
      const { id, created_at, updated_at, ...quoteDataToCopy } = fullQuote;
      
      const newQuotePayload = {
        ...quoteDataToCopy,
        client_id: newClientId,
        status: "Draft",
        quote_number: newQuoteNumber,
        // Clear client-specific fields
        lead_id: null,
        site_address: selectedClient?.site_address || selectedClient?.billing_address || "",
        cover_page_title: "",
        cover_page_subtitle: "",
        client_goals_notes: "",
        client_selected_items_json: null,
        sent_at: null,
        viewed_at: null,
        signed_at: null,
        signed_by: null,
        client_signature: null
      };

      // D. Insert new quote to get the fresh ID
      const { data: newQuote, error: newQuoteErr } = await supabase
        .from("quotes")
        .insert([newQuotePayload])
        .select()
        .single();
        
      if (newQuoteErr) throw newQuoteErr;

      // E. Copy Phases (Sequentially, so we can map old IDs to new IDs)
      const phaseMap = {}; // Maps old phase_id to new phase_id
      if (phases && phases.length > 0) {
        for (const phase of phases) {
          const { id: oldPhaseId, created_at, updated_at, ...phaseToCopy } = phase;
          const { data: newPhase, error: newPhaseErr } = await supabase
            .from("quote_phases")
            .insert([{ ...phaseToCopy, quote_id: newQuote.id }])
            .select()
            .single();
            
          if (newPhaseErr) throw newPhaseErr;
          phaseMap[oldPhaseId] = newPhase.id;
        }
      }

      // F. Copy Line Items (Bulk insert, swapping old phase_ids for new ones)
      if (items && items.length > 0) {
        const newItemsPayload = items.map(item => {
          const { id: oldItemId, created_at, updated_at, ...itemToCopy } = item;
          return {
            ...itemToCopy,
            quote_id: newQuote.id,
            phase_id: itemToCopy.phase_id ? (phaseMap[itemToCopy.phase_id] || null) : null
          };
        });
        
        const { error: newItemsErr } = await supabase.from("quote_line_items").insert(newItemsPayload);
        if (newItemsErr) throw newItemsErr;
      }

      // G. Copy Payment Schedule
      if (fullQuote.has_payment_schedule && scheduleItems && scheduleItems.length > 0) {
        const newSchedulePayload = scheduleItems.map(sched => {
          const { id: oldSchedId, created_at, updated_at, ...schedToCopy } = sched;
          return {
            ...schedToCopy,
            quote_id: newQuote.id
          };
        });
        
        const { error: newSchedErr } = await supabase.from("quote_payment_schedule").insert(newSchedulePayload);
        if (newSchedErr) throw newSchedErr;
      }

      return newQuote;
    },
    onSuccess: () => {
      toast.success("Quote duplicated successfully!");
      queryClient.invalidateQueries({ queryKey: ["quotes"] });
      onOpenChange(false);
      setSelectedClientId("");
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to duplicate quote");
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-slate-50 border-slate-200 shadow-xl" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="font-black text-xl flex items-center gap-2 text-slate-900">
            <Copy className="h-5 w-5 text-amber-500" /> Duplicate Quote
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 pt-4">
          <p className="text-sm font-medium text-slate-600 mb-2">
            Select the client who will receive this copied estimate. All phases, line items, and pricing will carry over.
          </p>
          
          <div>
            <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5 block">Select Client *</Label>
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
              <SelectTrigger className="bg-white font-bold border-slate-200 shadow-sm">
                <SelectValue placeholder="Choose a client..." />
              </SelectTrigger>
              <SelectContent>
                {clients.map((client) => (
                  <SelectItem key={client.id} value={client.id} className="font-bold">
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 mt-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={duplicateMutation.isPending}
              className="font-bold border-slate-300"
            >
              Cancel
            </Button>
            <Button
              onClick={() => duplicateMutation.mutate(selectedClientId)}
              disabled={!selectedClientId || duplicateMutation.isPending}
              className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-black shadow-md min-w-[120px]"
            >
              {duplicateMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
              {duplicateMutation.isPending ? "Copying..." : "Duplicate"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}