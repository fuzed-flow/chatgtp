import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext"; 
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label"; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Trash2, MoveRight, Image as ImageIcon, GripVertical, Search } from "lucide-react";
import ProductSearchOrCreate from "./ProductSearchOrCreate";
import ProductSearchDialog from "./ProductSearchDialog";

const UNITS = ["ea", "ft", "sqft", "hr", "lft", "m", "sqm", "bag", "box", "roll"];

export default function LineItemRow({ 
  item, 
  itemIdx, 
  phaseIdx, 
  phases,
  onUpdate, 
  onDuplicate, 
  onMove, 
  onRemove,
  onPhotoUpload,
  clientSelections,
  dragHandleProps
}) {
  const { settings } = useAuth(); 
  const defaultMargin = settings?.default_margin ?? 20;

  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [showCostBreakdown, setShowCostBreakdown] = useState(false);

  // Local state for text display only (keeps cursor stable during typing)
  const [localQty, setLocalQty] = useState(String(item.quantity || 1));
  const [localUnit, setLocalUnit] = useState(item.unit || "ea");
  
  // Cost Breakdown
  const [localMatCost, setLocalMatCost] = useState(String(item.material_cost || 0));
  const [localLabCost, setLocalLabCost] = useState(String(item.labor_cost || 0));
  const [localTotalCost, setLocalTotalCost] = useState(String(item.unit_cost || 0));
  
  const [localPrice, setLocalPrice] = useState(String(item.unit_price || 0));
  const [localDesc, setLocalDesc] = useState(item.description || "");
  const [localNotes, setLocalNotes] = useState(item.internal_notes || "");
  
  // Supplier & Material State
  const [localSupplier, setLocalSupplier] = useState(item.supplier || "");

  // Give Margin its own stable local state to prevent "Rounding Whiplash"
  const [localMargin, setLocalMargin] = useState(() => {
    const c = Number(item.unit_cost || 0);
    const p = Number(item.unit_price || 0);
    return c > 0 && p > 0 ? (((p - c) / p) * 100).toFixed(1) : "";
  });

  // Only sync from parent on external product selection changes (not on every keystroke)
  const itemIdRef = useRef(item.id);
  useEffect(() => {
    if (item.id !== itemIdRef.current) {
      itemIdRef.current = item.id;
      setLocalQty(String(item.quantity || 1));
      setLocalUnit(item.unit || "ea");
      setLocalMatCost(String(item.material_cost || 0));
      setLocalLabCost(String(item.labor_cost || 0));
      setLocalTotalCost(String(item.unit_cost || 0));
      setLocalPrice(String(item.unit_price || 0));
      setLocalDesc(item.description || "");
      setLocalNotes(item.internal_notes || "");
      setLocalSupplier(item.supplier || ""); // Sync Supplier
      
      const c = Number(item.unit_cost || 0);
      const p = Number(item.unit_price || 0);
      setLocalMargin(c > 0 && p > 0 ? (((p - c) / p) * 100).toFixed(1) : "");
    }
  });

  const updateField = (field, value) => {
    onUpdate(phaseIdx, itemIdx, field, value);
  };

  const handleProductSelect = (name, product) => {
    if (product) {
      updateField("name", product.name);
      updateField("description", product.description || "");
      setLocalDesc(product.description || "");
      updateField("unit", product.unit || "ea");
      setLocalUnit(product.unit || "ea");
      
      const mat = Number(product.material_cost) || 0;
      const lab = Number(product.labor_cost) || 0;
      const tot = Number(product.cost) || (mat + lab) || Number(item.unit_cost);
      
      updateField("material_cost", mat);
      setLocalMatCost(String(mat));
      setTimeout(() => { updateField("labor_cost", lab); setLocalLabCost(String(lab)); }, 10);
      setTimeout(() => { updateField("unit_cost", tot); setLocalTotalCost(String(tot)); }, 20);
      
      const pPrice = product.price || item.unit_price || 0;
      setTimeout(() => {
        updateField("unit_price", pPrice);
        setLocalPrice(String(pPrice));
      }, 30);
      
      if (tot > 0 && pPrice > 0) {
        setLocalMargin((((pPrice - tot) / pPrice) * 100).toFixed(1));
      }
      
      updateField("product_id", product.id);
      updateField("photo_url", product.image_url || item.photo_url);

      // Auto-extract material/supplier data from product
      if (product.supplier) {
        updateField("supplier", product.supplier);
        setLocalSupplier(product.supplier);
      }
      if (product.is_material) {
        updateField("is_material", true);
      }

      if (mat > 0 || lab > 0) setShowCostBreakdown(true);

    } else {
      updateField("name", name);
    }
  };

  const handleMatLabChange = (field, val) => {
    const newVal = Number(val) || 0;
    const isMat = field === 'material';
    
    if (isMat) {
      setLocalMatCost(val);
      updateField("material_cost", newVal);
    } else {
      setLocalLabCost(val);
      updateField("labor_cost", newVal);
    }

    const otherVal = isMat ? Number(localLabCost) : Number(localMatCost);
    const newTotal = Number((newVal + otherVal).toFixed(2));
    
    setLocalTotalCost(String(newTotal));
    setTimeout(() => updateField("unit_cost", newTotal), 10);

    const oldTotal = Number(localTotalCost) || 0;
    const oldPrice = Number(localPrice) || 0;
    
    let marginPct = defaultMargin / 100;
    if (oldTotal > 0 && oldPrice > 0) {
      marginPct = (oldPrice - oldTotal) / oldPrice; 
    }
    
    if (marginPct >= 0 && marginPct < 1) {
      const newPrice = Number((newTotal / (1 - marginPct)).toFixed(2));
      setLocalPrice(String(newPrice));
      setLocalMargin((marginPct * 100).toFixed(1));
      setTimeout(() => updateField("unit_price", newPrice), 20);
    }
  };

  const handleTotalCostChange = (val) => {
    const newTotal = Number(val) || 0;
    setLocalTotalCost(val);
    setTimeout(() => updateField("unit_cost", newTotal), 10);
    
    const oldTotal = Number(localTotalCost) || 0;
    const oldPrice = Number(localPrice) || 0;
    
    let marginPct = defaultMargin / 100;
    if (oldTotal > 0 && oldPrice > 0) {
      marginPct = (oldPrice - oldTotal) / oldPrice; 
    }

    if (marginPct >= 0 && marginPct < 1) {
      const newPrice = Number((newTotal / (1 - marginPct)).toFixed(2));
      setLocalPrice(String(newPrice));
      setLocalMargin((marginPct * 100).toFixed(1));
      setTimeout(() => updateField("unit_price", newPrice), 30);
    }

    setLocalMatCost("0");
    setLocalLabCost("0");
    setTimeout(() => updateField("material_cost", 0), 10);
    setTimeout(() => updateField("labor_cost", 0), 20);
  };

  const isItemModified = clientSelections && item.is_optional && item.id ? (() => {
    const clientSelected = clientSelections[item.id] !== false;
    return clientSelected !== (item.default_selected === true);
  })() : false;

  return (
    <div className={`p-3 rounded-lg border transition-colors ${isItemModified ? 'bg-red-50 border-red-500 border-2 shadow-sm' : 'bg-slate-50 border-slate-200 hover:border-amber-400 shadow-sm'}`}>
      {isItemModified && (
        <div className="bg-red-600 text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded mb-2 inline-block shadow-sm">
          CLIENT MODIFIED
        </div>
      )}
      
      {/* Product row */}
      <div className="mb-3">
        <Label className={`text-[10px] uppercase font-black tracking-wider mb-1 block ${isItemModified ? 'text-red-900' : 'text-slate-500'}`}>Product / Line Item</Label>
        <div className="flex gap-2 items-center">
          <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing p-1.5 rounded-md hover:bg-slate-200 shrink-0 transition-colors" title="Drag to reorder">
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
          
          <ProductSearchOrCreate
            value={item.name}
            initialData={{
              name: item.name,
              description: localDesc,
              unit: localUnit,
              material_cost: localMatCost,
              labor_cost: localLabCost,
              unit_cost: localTotalCost,
              unit_price: localPrice,
              taxable: item.taxable,
              photo_url: item.photo_url
            }}
            onSelect={handleProductSelect}
            onProductCreated={(product) => handleProductSelect(product.name, product)}
          />

          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-9 w-9 shrink-0 bg-white border-slate-300 shadow-sm hover:border-amber-400 transition-colors"
            title="Browse product catalog"
            onClick={() => setProductDialogOpen(true)}
          >
            <Search className="h-4 w-4 text-amber-600" />
          </Button>
        </div>
        <ProductSearchDialog
          open={productDialogOpen}
          onOpenChange={setProductDialogOpen}
          onSelect={handleProductSelect}
        />
      </div>
      
      {/* Numbers row */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm mb-3">
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 items-start">
          <div>
            <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5 block">Qty</Label>
            <Input 
              type="number" 
              value={localQty}
              onChange={e => { setLocalQty(e.target.value); updateField("quantity", Number(e.target.value)); }}
              className="text-sm h-9 font-black text-slate-900 border-slate-300" 
            />
          </div>
          <div>
            <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5 block">Unit</Label>
            <Select 
              value={localUnit} 
              onValueChange={v => { setLocalUnit(v); updateField("unit", v); }}
            >
              <SelectTrigger className="h-9 text-xs font-bold border-slate-300"><SelectValue /></SelectTrigger>
              <SelectContent>{UNITS.map(u => <SelectItem key={u} value={u} className="font-bold">{u}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          {/* COST BLOCK WITH M/L SPLIT */}
          <div className="col-span-2 relative bg-slate-50/50 p-2 rounded-lg border border-slate-100 -mt-2">
            <div className="flex items-center justify-between mb-1.5">
              <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Unit Cost</Label>
              <button 
                type="button" 
                onClick={() => setShowCostBreakdown(!showCostBreakdown)} 
                className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded transition-colors ${showCostBreakdown ? 'bg-slate-200 text-slate-600' : 'bg-amber-100 text-amber-700 hover:bg-amber-200'}`}
              >
                {showCostBreakdown ? "Hide M/L" : "Split M/L"}
              </button>
            </div>
            
            {showCostBreakdown && (
              <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-200 border-dashed">
                <div className="relative flex-1">
                  <span className="absolute left-2 top-2 text-[10px] font-black text-slate-400">M:</span>
                  <Input type="number" step="0.01" value={localMatCost} onChange={e => handleMatLabChange('material', e.target.value)} className="h-8 text-xs font-bold pl-6 border-slate-300 bg-white" />
                </div>
                <div className="relative flex-1">
                  <span className="absolute left-2 top-2 text-[10px] font-black text-slate-400">L:</span>
                  <Input type="number" step="0.01" value={localLabCost} onChange={e => handleMatLabChange('labor', e.target.value)} className="h-8 text-xs font-bold pl-5 border-slate-300 bg-white" />
                </div>
              </div>
            )}
            
            <div className="relative">
              {showCostBreakdown && <span className="absolute left-2 top-2 text-[10px] font-black text-slate-400">Total:</span>}
              <Input 
                type="number" 
                step="0.01" 
                value={localTotalCost}
                onChange={e => handleTotalCostChange(e.target.value)}
                className={`text-sm h-9 font-bold text-slate-900 border-slate-300 ${showCostBreakdown ? 'bg-slate-100 pl-11' : 'bg-white'}`} 
              />
            </div>
          </div>

          <div>
            <Label className="text-[10px] font-black uppercase tracking-wider text-amber-600 mb-1.5 block">Unit Price</Label>
            <Input 
              type="number" 
              step="0.01" 
              value={localPrice}
              onChange={e => { 
                setLocalPrice(e.target.value); 
                updateField("unit_price", Number(e.target.value)); 
                
                // Recalculate Margin safely
                const p = Number(e.target.value);
                const c = Number(localTotalCost);
                if (p > 0 && c > 0) {
                  setLocalMargin((((p - c) / p) * 100).toFixed(1));
                }
              }}
              className="text-sm h-9 font-black text-amber-900 border-amber-300 bg-amber-50 shadow-inner" 
            />
          </div>

          <div>
            <Label className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5 block">Margin</Label>
            <div className="relative">
              <Input
                type="number"
                step="0.1"
                min="-100"
                max="100"
                value={localMargin}
                onChange={e => {
                  setLocalMargin(e.target.value); 
                  
                  const pct = Number(e.target.value);
                  if (Number(localTotalCost) > 0 && pct < 100) {
                    const newPrice = Number(localTotalCost) / (1 - pct / 100);
                    const rounded = String(Math.round(newPrice * 100) / 100);
                    setLocalPrice(rounded);
                    updateField("unit_price", Number(rounded));
                  }
                }}
                className="text-sm h-9 font-bold text-emerald-700 bg-emerald-50 border-emerald-200 pr-6"
              />
              <span className="absolute right-2 top-2 text-[10px] font-black text-emerald-700">%</span>
            </div>
            <div className="text-[9px] font-black text-emerald-600 text-center mt-1.5 whitespace-nowrap tracking-wider">
              Profit: ${((Number(localQty) * Number(localPrice)) - (Number(localQty) * Number(localTotalCost))).toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Options row */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div className="flex flex-wrap items-center gap-4 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
          <label className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-slate-700 cursor-pointer hover:opacity-70 transition-opacity">
            <input 
              type="checkbox" 
              checked={item.taxable} 
              onChange={e => updateField("taxable", e.target.checked)} 
              className="rounded border-slate-300 text-amber-500 focus:ring-amber-500 w-3.5 h-3.5" 
            />
            Taxable
          </label>
          <div className="w-px h-4 bg-slate-200"></div>
          
          <label className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-slate-900 cursor-pointer hover:opacity-70 transition-opacity">
            <input 
              type="checkbox" 
              checked={item.is_material === true} 
              onChange={e => updateField("is_material", e.target.checked)} 
              className="rounded border-slate-300 text-amber-500 focus:ring-amber-500 w-3.5 h-3.5" 
            />
            Track Material
          </label>

          {item.is_material && (
            <>
              <div className="w-px h-4 bg-slate-200"></div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Supplier:</span>
                <input
                  type="text"
                  placeholder="Supplier Name..."
                  value={localSupplier}
                  onChange={e => setLocalSupplier(e.target.value)}
                  onBlur={e => updateField("supplier", e.target.value)}
                  className="h-7 text-[11px] font-bold border border-slate-300 rounded bg-amber-50/40 px-2 outline-none focus:border-amber-500 w-[140px]"
                />
              </div>
            </>
          )}

          <div className="w-px h-4 bg-slate-200"></div>

          <label className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-slate-700 cursor-pointer hover:opacity-70 transition-opacity">
            <input 
              type="checkbox" 
              checked={item.is_optional === true} 
              onChange={e => updateField("is_optional", e.target.checked)} 
              className="rounded border-slate-300 text-amber-500 focus:ring-amber-500 w-3.5 h-3.5" 
            />
            Optional
          </label>
          
          {item.is_optional && (
            <>
              <div className="w-px h-4 bg-slate-200"></div>
              <label className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-slate-500 cursor-pointer hover:opacity-70 transition-opacity">
                <input 
                  type="checkbox" 
                  checked={item.default_selected === true} 
                  onChange={e => updateField("default_selected", e.target.checked)} 
                  className="rounded border-slate-300 text-amber-500 focus:ring-amber-500 w-3.5 h-3.5" 
                />
                Pre-select
              </label>
            </>
          )}
        </div>
        
        <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 shadow-sm">
           <Button variant="ghost" size="icon" className="h-7 w-7 hover:bg-blue-50 hover:text-blue-600 rounded-md" onClick={() => onDuplicate(phaseIdx, itemIdx)} title="Duplicate">
             <Copy className="h-3.5 w-3.5" />
           </Button>
           {phases?.length > 1 && (
             <Select onValueChange={v => onMove(phaseIdx, itemIdx, Number(v))}>
               <SelectTrigger className="h-7 w-7 p-0 border-none bg-transparent hover:bg-slate-100 rounded-md flex items-center justify-center [&>svg]:hidden" title="Move to phase">
                 <MoveRight className="h-3.5 w-3.5 text-slate-600" />
               </SelectTrigger>
               <SelectContent>
                 {phases.map((p, pIdx) => pIdx !== phaseIdx && (
                   <SelectItem key={pIdx} value={String(pIdx)} className="font-bold text-xs">Move to {p.phase_name}</SelectItem>
                 ))}
               </SelectContent>
             </Select>
           )}
           <Button variant="ghost" size="icon" className="h-7 w-7 hover:bg-red-50 hover:text-red-600 rounded-md" onClick={() => onRemove(phaseIdx, itemIdx)} title="Remove Item">
             <Trash2 className="h-3.5 w-3.5" />
           </Button>
         </div>
      </div>
      
      <div className="flex gap-4 items-start">
        <div className="flex-1 space-y-3">
          <Textarea
           value={localDesc}
           onChange={e => { setLocalDesc(e.target.value); updateField("description", e.target.value); }}
           placeholder="Description (shown to client on quote)..."
           className="text-sm bg-white border-slate-200 text-slate-900 resize-y min-h-[60px] shadow-sm font-medium"
           rows={2}
          />
          <Textarea
           value={localNotes}
           onChange={e => { setLocalNotes(e.target.value); updateField("internal_notes", e.target.value); }}
           placeholder="Internal notes (hidden from client)..."
           className="text-xs bg-amber-50/50 border-amber-200 text-slate-700 resize-y min-h-[40px] placeholder:text-amber-500/60 font-medium"
           rows={1}
          />
        </div>
        
        <div className="flex flex-col items-center gap-1.5 shrink-0 pt-1">
          {item.photo_url ? (
            <div className="relative group">
              <img src={item.photo_url} alt={item.name} className="h-28 w-28 object-cover rounded-xl border border-slate-200 shadow-md bg-white" />
              <button
                onClick={() => updateField("photo_url", "")}
                className="absolute -top-2 -right-2 bg-slate-900 hover:bg-red-600 text-white rounded-full h-6 w-6 flex items-center justify-center text-sm font-black opacity-0 group-hover:opacity-100 transition-all shadow-lg"
              >
                ×
              </button>
            </div>
          ) : (
            <label className="h-28 w-28 border-2 border-dashed border-slate-300 bg-white rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-amber-400 hover:bg-amber-50 transition-colors shadow-sm">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && onPhotoUpload(phaseIdx, itemIdx, e.target.files[0])}
              />
              <ImageIcon className="h-6 w-6 text-slate-300 mb-1.5" />
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Photo</span>
            </label>
          )}
        </div>
      </div>

    </div>
  );
}