import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/api/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { useNavigate } from "react-router-dom";
import { format, parseISO } from "date-fns";
import { 
  HardHat, AlertTriangle, CloudSun, Plus, ArrowRight, ShieldAlert, FileText,
  Camera, X, Hammer, Briefcase, AlignLeft, Maximize2, ChevronLeft, ChevronRight
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const WEATHER = ["Sunny", "Cloudy", "Rainy", "Snowy", "Windy", "Hot", "Cold"];

export default function DashboardNotes() {
  const { profile } = useAuth();
  const companyId = profile?.company_id;
  const navigate = useNavigate();
  const qc = useQueryClient();

  // --- MODAL & FORM STATES ---
  const [openSubmit, setOpenSubmit] = useState(false);
  const [selectedViewLog, setSelectedViewLog] = useState(null);
  
  // Upgraded Lightbox State
  const [lightbox, setLightbox] = useState({ isOpen: false, photos: [], index: 0 });
  
  const [uploading, setUploading] = useState(false);
  
  const defaultForm = { 
    date: format(new Date(), "yyyy-MM-dd"), project_id: "", summary: "", blockers: "", safety_concerns: "", materials_used: "", weather: "Sunny", photos: [] 
  };
  const [form, setForm] = useState(defaultForm);

  // --- QUERIES ---
  const { data: projects = [] } = useQuery({ 
    queryKey: ["projects", companyId], enabled: !!companyId,
    queryFn: async () => { const { data } = await supabase.from("projects").select("id, name").eq("company_id", companyId); return data || []; } 
  });

  const { data: users = [] } = useQuery({
    queryKey: ["company_users", companyId], enabled: !!companyId,
    queryFn: async () => {
      const { data: u } = await supabase.from("users").select("id, full_name, email").eq("company_id", companyId);
      const { data: p } = await supabase.from("profiles").select("id, full_name").eq("company_id", companyId);
      return [...(u || []), ...(p || [])];
    }
  });

  const { data: recentLogs = [], isLoading } = useQuery({
    queryKey: ["project_daily_logs", companyId], enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("project_daily_logs").select("*").eq("company_id", companyId).order("date", { ascending: false }).order("created_at", { ascending: false }).limit(15); 
      if (error) throw error; return data || [];
    }
  });

  // --- MUTATIONS ---
  const createMutation = useMutation({
    mutationFn: async (payload) => {
      const dbPayload = {
        company_id: companyId, user_id: profile.id, project_id: payload.project_id, date: payload.date, weather: payload.weather, summary: payload.summary, blockers: payload.blockers || null, safety_concerns: payload.safety_concerns || null, materials_used: payload.materials_used || null, photos: payload.photos || []
      };
      const { data, error } = await supabase.from("project_daily_logs").insert([dbPayload]);
      if (error) throw error; return data;
    },
    onSuccess: () => { 
      qc.invalidateQueries({ queryKey: ["project_daily_logs"] }); 
      qc.invalidateQueries({ queryKey: ["daily_logs_mine"] }); 
      setOpenSubmit(false); setForm(defaultForm);
      toast.success("Field log submitted successfully!"); 
    },
    onError: (err) => toast.error(`Failed to save log: ${err.message}`)
  });

  // --- HANDLERS ---
  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    const urls = [...form.photos];
    try {
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `${profile.id}/${fileName}`;
        const { error } = await supabase.storage.from('daily_logs').upload(filePath, file);
        if (error) throw error;
        const { data } = supabase.storage.from('daily_logs').getPublicUrl(filePath);
        urls.push(data.publicUrl);
      }
      setForm({ ...form, photos: urls });
      toast.success(`${files.length} photo(s) uploaded!`);
    } catch (err) { toast.error(`Upload failed: ${err.message}`); } finally { setUploading(false); }
  };

  const nextPhoto = (e) => {
    e.stopPropagation();
    setLightbox(prev => ({ ...prev, index: Math.min(prev.index + 1, prev.photos.length - 1) }));
  };

  const prevPhoto = (e) => {
    e.stopPropagation();
    setLightbox(prev => ({ ...prev, index: Math.max(prev.index - 1, 0) }));
  };

  const projectMap = Object.fromEntries(projects.map(p => [p.id, p.name]));
  const userMap = Object.fromEntries(users.map(u => [u.id, u.full_name || u.email]));

  return (
    <>
      <Card className="h-full flex flex-col border-slate-200 shadow-sm bg-white overflow-hidden relative">
        {/* HEADER */}
        <div className="p-5 md:p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <HardHat className="h-5 w-5 text-amber-500" /> Recent Field Logs
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-1">Updates from the job sites</p>
          </div>
          <Button size="sm" onClick={() => setOpenSubmit(true)} className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-black shadow-md shadow-amber-500/20">
            <Plus className="h-4 w-4 mr-1.5" /> Submit Log
          </Button>
        </div>

        {/* FEED CONTENT */}
        <div className="flex-1 overflow-y-auto p-5 md:p-6 space-y-4">
          {isLoading ? (
            <div className="flex justify-center py-10"><div className="h-6 w-6 border-2 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div></div>
          ) : recentLogs.length === 0 ? (
            <div className="text-center py-10">
              <FileText className="h-10 w-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-bold text-slate-700">No field logs submitted yet.</p>
              <p className="text-xs text-slate-500 mt-1">When your crew submits daily logs, they will appear here.</p>
            </div>
          ) : (
            recentLogs.map((log) => {
              const hasBlocker = log.blockers && log.blockers.trim().length > 0;
              const hasSafety = log.safety_concerns && log.safety_concerns.trim().length > 0;
              const hasPhotos = log.photos && log.photos.length > 0;
              const logDate = log.date ? parseISO(log.date) : parseISO(log.created_at);

              return (
                <div key={log.id} className="relative pl-4 border-l-2 border-slate-200 pb-2 group">
                  {/* Timeline Dot */}
                  <div className={`absolute -left-[9px] top-1 h-4 w-4 rounded-full border-4 border-white ${hasBlocker || hasSafety ? 'bg-red-500' : 'bg-blue-500'}`}></div>
                  
                  {/* Clickable Feed Card */}
                  <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer" onClick={() => setSelectedViewLog(log)}>
                    
                    {/* Meta Data */}
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">
                          {projectMap[log.project_id] || "General Update"}
                        </h4>
                        <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 mt-0.5">
                          {format(logDate, "MMM d, yyyy")} • By {userMap[log.user_id] || "Unknown User"}
                        </p>
                      </div>
                      {log.weather && (
                        <div className="flex items-center gap-1 text-xs font-medium text-slate-500 bg-white px-2 py-1 rounded-md border border-slate-100 shadow-sm" title="Weather">
                          <CloudSun className="h-3 w-3 text-amber-500" /> {log.weather}
                        </div>
                      )}
                    </div>

                    {/* Summary */}
                    <p className="text-sm text-slate-700 line-clamp-2">
                      {log.summary || <span className="italic text-slate-400">No summary provided.</span>}
                    </p>

                    {/* Visual Photo Thumbnails directly on Dashboard */}
                    {hasPhotos && (
                      <div className="flex gap-2 mt-3 pt-2">
                        {log.photos.slice(0, 3).map((url, i) => (
                          <div 
                            key={i} 
                            onClick={(e) => { e.stopPropagation(); setLightbox({ isOpen: true, photos: log.photos, index: i }); }}
                            className="h-12 w-12 rounded-md overflow-hidden border border-slate-200 shadow-sm bg-white hover:opacity-80 transition-opacity"
                          >
                            <img src={url} alt="Thumbnail" className="h-full w-full object-cover" />
                          </div>
                        ))}
                        {log.photos.length > 3 && (
                          <div 
                            onClick={(e) => { e.stopPropagation(); setLightbox({ isOpen: true, photos: log.photos, index: 3 }); }}
                            className="h-12 w-12 rounded-md bg-slate-200 border border-slate-300 flex items-center justify-center text-xs font-bold text-slate-600 shadow-sm hover:bg-slate-300 transition-colors"
                          >
                            +{log.photos.length - 3}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Badges for Blockers / Safety */}
                    {(hasBlocker || hasSafety) && (
                      <div className="flex gap-2 mt-3 pt-3 border-t border-slate-200/60">
                        {hasBlocker && (
                          <div className="flex items-center gap-1 text-[10px] font-bold text-red-700 bg-red-50 px-2 py-1 rounded-md">
                            <AlertTriangle className="h-3 w-3" /> BLOCKER
                          </div>
                        )}
                        {hasSafety && (
                          <div className="flex items-center gap-1 text-[10px] font-bold text-orange-700 bg-orange-50 px-2 py-1 rounded-md">
                            <ShieldAlert className="h-3 w-3" /> SAFETY CONCERN
                          </div>
                        )}
                      </div>
                    )}

                    {/* Hover Arrow */}
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowRight className="h-4 w-4 text-slate-400" />
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
        
        {/* FOOTER */}
        {recentLogs.length > 0 && (
          <div className="p-4 border-t border-slate-100 bg-slate-50 text-center">
            <Button variant="link" size="sm" className="text-slate-500 hover:text-slate-900" onClick={() => navigate('/DailyLogs')}>
              View All Field Logs
            </Button>
          </div>
        )}
      </Card>

      {/* --- QUICK VIEW DETAILS MODAL --- */}
      {selectedViewLog && (
        <Dialog open={!!selectedViewLog} onOpenChange={() => setSelectedViewLog(null)}>
          <DialogContent className="max-w-xl bg-slate-50 border-slate-200 shadow-xl max-h-[90vh] overflow-y-auto" aria-describedby={undefined}>
            <DialogHeader>
              <div className="flex items-start justify-between pr-6 border-b border-slate-200 pb-4">
                <div>
                  <DialogTitle className="font-black text-2xl text-slate-900 mb-1">
                    Log: {selectedViewLog.date}
                  </DialogTitle>
                  <p className="text-sm font-bold text-slate-500 flex items-center gap-1.5">
                    <CloudSun className="h-4 w-4" /> Weather: {selectedViewLog.weather || "Not recorded"}
                  </p>
                </div>
                {projects.find(p => p.id === selectedViewLog.project_id) && (
                  <Badge className="bg-amber-100 text-amber-800 border-amber-200 mt-1 shadow-sm">
                    <Briefcase className="h-3.5 w-3.5 mr-1.5" />
                    {projects.find(p => p.id === selectedViewLog.project_id)?.name}
                  </Badge>
                )}
              </div>
            </DialogHeader>
            
            <div className="space-y-6 pt-2">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
                  <AlignLeft className="h-4 w-4" /> Work Completed Today
                </h4>
                <div className="bg-white p-4 rounded-xl border border-slate-200 text-sm text-slate-700 leading-relaxed whitespace-pre-wrap shadow-sm">
                  {selectedViewLog.summary}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {selectedViewLog.blockers && (
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-orange-500 flex items-center gap-1.5 mb-2">
                      <AlertTriangle className="h-4 w-4" /> Issues / Delays
                    </h4>
                    <div className="bg-orange-50 p-3 rounded-xl border border-orange-200 text-sm text-orange-900 whitespace-pre-wrap shadow-sm">
                      {selectedViewLog.blockers}
                    </div>
                  </div>
                )}
                {selectedViewLog.safety_concerns && (
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-red-500 flex items-center gap-1.5 mb-2">
                      <ShieldAlert className="h-4 w-4" /> Safety Concerns
                    </h4>
                    <div className="bg-red-50 p-3 rounded-xl border border-red-200 text-sm text-red-900 whitespace-pre-wrap shadow-sm">
                      {selectedViewLog.safety_concerns}
                    </div>
                  </div>
                )}
              </div>

              {selectedViewLog.materials_used && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
                    <Hammer className="h-4 w-4" /> Materials Used
                  </h4>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 text-sm font-medium text-slate-700 shadow-sm">
                    {selectedViewLog.materials_used}
                  </div>
                </div>
              )}

              {selectedViewLog.photos && selectedViewLog.photos.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
                    <Camera className="h-4 w-4" /> Attached Photos (Click to Enlarge)
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {selectedViewLog.photos.map((url, i) => (
                      <div 
                        key={i} 
                        onClick={() => setLightbox({ isOpen: true, photos: selectedViewLog.photos, index: i })} 
                        className="relative block group overflow-hidden rounded-xl border border-slate-200 bg-white cursor-pointer shadow-sm"
                      >
                        <img src={url} alt={`Log attachment ${i+1}`} className="w-full h-32 object-cover transition-transform group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                          <Maximize2 className="text-white opacity-0 group-hover:opacity-100 drop-shadow-md h-6 w-6" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <DialogFooter className="border-t border-slate-200 pt-4 mt-2">
              <Button 
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold"
                onClick={() => {
                  setSelectedViewLog(null);
                  navigate(`/ProjectDetail?id=${selectedViewLog.project_id}&tab=logs`);
                }}
              >
                Open Project Workspace <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* --- UPGRADED FULLSCREEN IMAGE LIGHTBOX GALLERY --- */}
      {lightbox.isOpen && lightbox.photos.length > 0 && (
        <div 
          className="fixed inset-0 z-[100] bg-slate-950/98 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in duration-200"
          onClick={() => setLightbox({ isOpen: false, photos: [], index: 0 })}
        >
          {/* Close Button */}
          <button 
            className="absolute top-4 right-4 sm:top-6 sm:right-6 text-white/50 hover:text-white bg-black/20 hover:bg-black/50 rounded-full p-3 transition-all"
            onClick={(e) => { e.stopPropagation(); setLightbox({ isOpen: false, photos: [], index: 0 }); }}
          >
            <X className="h-6 w-6 sm:h-8 sm:w-8" />
          </button>

          {/* Previous Button */}
          {lightbox.index > 0 && (
            <button 
              className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 text-white/50 hover:text-white bg-black/20 hover:bg-black/50 rounded-full p-2 sm:p-4 transition-all"
              onClick={prevPhoto}
            >
              <ChevronLeft className="h-8 w-8 sm:h-10 sm:w-10" />
            </button>
          )}

          {/* Main Image */}
          <img 
            src={lightbox.photos[lightbox.index]} 
            alt={`Field photo ${lightbox.index + 1}`} 
            className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl transition-transform duration-300" 
            onClick={(e) => e.stopPropagation()} 
          />

          {/* Next Button */}
          {lightbox.index < lightbox.photos.length - 1 && (
            <button 
              className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 text-white/50 hover:text-white bg-black/20 hover:bg-black/50 rounded-full p-2 sm:p-4 transition-all"
              onClick={nextPhoto}
            >
              <ChevronRight className="h-8 w-8 sm:h-10 sm:w-10" />
            </button>
          )}

          {/* Photo Counter */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/40 text-white font-bold text-sm tracking-widest px-4 py-2 rounded-full">
            {lightbox.index + 1} / {lightbox.photos.length}
          </div>
        </div>
      )}

      {/* --- SUBMIT LOG FORM MODAL --- */}
      <Dialog open={openSubmit} onOpenChange={(val) => !val && setOpenSubmit(false)}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto bg-slate-50" aria-describedby={undefined}>
          <DialogHeader><DialogTitle className="font-black text-xl">New Project Note</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Date</label>
                <Input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="mt-1 bg-white font-medium" />
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Weather</label>
                <Select value={form.weather} onValueChange={v => setForm({ ...form, weather: v })}>
                  <SelectTrigger className="mt-1 bg-white font-medium"><SelectValue /></SelectTrigger>
                  <SelectContent>{WEATHER.map(w => <SelectItem key={w} value={w}>{w}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Project Location *</label>
              <Select value={form.project_id} onValueChange={v => setForm({ ...form, project_id: v })}>
                <SelectTrigger className="mt-1 bg-white font-medium"><SelectValue placeholder="Select a project..." /></SelectTrigger>
                <SelectContent>
                  {projects.length === 0 ? <SelectItem value="none" disabled>No projects available</SelectItem> : projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Work Completed Today *</label>
              <Textarea value={form.summary} onChange={e => setForm({ ...form, summary: e.target.value })} rows={3} className="mt-1 bg-white" placeholder="Describe the work done..." />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-orange-600">Issues / Delays</label>
                <Textarea value={form.blockers} onChange={e => setForm({ ...form, blockers: e.target.value })} rows={2} className="mt-1 bg-white border-orange-200" placeholder="Any blockers?" />
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-red-600">Safety Concerns</label>
                <Textarea value={form.safety_concerns} onChange={e => setForm({ ...form, safety_concerns: e.target.value })} rows={2} className="mt-1 bg-white border-red-200" placeholder="Incidents/hazards?" />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Materials Used</label>
              <Input value={form.materials_used} onChange={e => setForm({ ...form, materials_used: e.target.value })} className="mt-1 bg-white" placeholder="e.g., 5 bags concrete, 10 2x4s" />
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between mb-3">
                <span>Site Photos</span>
                <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded">{form.photos.length} attached</span>
              </label>
              {form.photos.length > 0 && (
                <div className="flex gap-2 flex-wrap mb-3">
                  {form.photos.map((url, i) => (
                    <div key={i} className="relative group">
                      <img src={url} alt="Upload preview" className="h-14 w-14 object-cover rounded-lg border border-slate-300" />
                      <button onClick={() => setForm({ ...form, photos: form.photos.filter((_, idx) => idx !== i) })} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity shadow-md"><X className="h-3 w-3" /></button>
                    </div>
                  ))}
                </div>
              )}
              <label className="flex items-center justify-center gap-2 px-3 py-4 border-2 border-dashed border-slate-300 bg-slate-50 rounded-xl cursor-pointer hover:bg-amber-50 hover:border-amber-400 hover:text-amber-700 transition-colors">
                {uploading ? <div className="h-5 w-5 border-2 border-amber-200 border-t-amber-500 rounded-full animate-spin" /> : <><Camera className="h-5 w-5 text-slate-400" /><span className="text-sm font-bold text-slate-600">Upload Photos</span></>}
                <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} disabled={uploading} />
              </label>
            </div>
            <DialogFooter className="pt-4 border-t border-slate-200 mt-4">
              <Button variant="outline" className="font-bold w-full" onClick={() => setOpenSubmit(false)}>Cancel</Button>
              <Button className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-black shadow-md w-full" onClick={() => createMutation.mutate(form)} disabled={!form.summary || !form.project_id || form.project_id === "none" || uploading || createMutation.isPending}>
                {createMutation.isPending ? "Saving..." : "Submit Log"}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}