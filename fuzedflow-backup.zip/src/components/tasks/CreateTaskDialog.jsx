import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const STATUSES = ["To Do", "Doing", "Blocked", "Done"];
const PRIORITIES = ["Low", "Medium", "High", "Urgent"];

// HELPER: Fallback to first/last name if `name` is blank
const getClientName = (c) => {
  if (!c) return "Unknown Client";
  if (c.name && c.name.trim() !== "") return c.name;
  const fullName = [c.first_name, c.surname].filter(Boolean).join(" ");
  if (fullName && fullName.trim() !== "") return fullName;
  if (c.primary_contact_name && c.primary_contact_name.trim() !== "") return c.primary_contact_name;
  return "Unnamed Client";
};

// HELPER: Fallback to project number if `name` is blank
const getProjectName = (p) => {
  if (!p) return "Unknown Project";
  if (p.name && p.name.trim() !== "") return p.name;
  if (p.project_number) return `Project #${p.project_number}`;
  return "Unnamed Project";
};

export default function CreateTaskDialog({
  open,
  onOpenChange,
  clients = [],
  projects = [],
  users = [],
  onSubmit,
  isLoading,
  defaultClientId = "none",
  defaultProjectId = "none",
}) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    client_id: "none",
    project_id: "none",
    assigned_to: "none",
    priority: "Medium",
    status: "To Do",
    due_date: "",
    estimated_hours: "",
  });

  // FIX: Safely stripped out array dependencies to prevent React infinite loops!
  useEffect(() => {
    if (open) {
      setFormData({
        title: "",
        description: "",
        client_id: defaultClientId,
        project_id: defaultProjectId,
        assigned_to: "none",
        priority: "Medium",
        status: "To Do",
        due_date: "",
        estimated_hours: "",
      });
    }
  }, [open, defaultClientId, defaultProjectId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    const payload = {
      ...formData,
      estimated_hours: formData.estimated_hours ? Number(formData.estimated_hours) : null,
      client_id: formData.client_id === "none" ? null : formData.client_id,
      project_id: formData.project_id === "none" ? null : formData.project_id,
      assigned_to: formData.assigned_to === "none" ? null : formData.assigned_to,
    };

    onSubmit(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg w-[95vw] rounded-xl p-4 sm:p-6 bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-black text-slate-900">Create Task</DialogTitle>
          <DialogDescription className="text-slate-500 font-medium">
            Add a new task and assign it to a team member
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-[10px] font-black uppercase tracking-wider text-slate-500">
              Task Title *
            </Label>
            <Input id="title" placeholder="Enter task title" value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} className="font-bold border-slate-200" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-[10px] font-black uppercase tracking-wider text-slate-500">
              Description
            </Label>
            <Textarea id="description" placeholder="Task description (optional)" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="h-24 resize-none font-medium border-slate-200" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="client" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Client</Label>
              <Select value={String(formData.client_id || "none")} onValueChange={(v) => setFormData({ ...formData, client_id: v })}>
                <SelectTrigger id="client" className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Client</SelectItem>
                  {clients.map((c) => (
                    <SelectItem key={String(c.id)} value={String(c.id)}>
                      {getClientName(c)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="project" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Project</Label>
              <Select value={String(formData.project_id || "none")} onValueChange={(v) => setFormData({ ...formData, project_id: v })}>
                <SelectTrigger id="project" className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Project</SelectItem>
                  {projects.map((p) => (
                    <SelectItem key={String(p.id)} value={String(p.id)}>
                      {getProjectName(p)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="assigned" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Assign To</Label>
              <Select value={String(formData.assigned_to || "none")} onValueChange={(v) => setFormData({ ...formData, assigned_to: v })}>
                <SelectTrigger id="assigned" className="font-medium border-slate-200 text-sm"><SelectValue placeholder="Select..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Unassigned</SelectItem>
                  {users.map((u) => (
                    <SelectItem key={String(u.id)} value={String(u.id)}>
                      {u.full_name || "Unknown User"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="priority" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Priority</Label>
              <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
                <SelectTrigger id="priority" className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Status</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                <SelectTrigger id="status" className="font-medium border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="due_date" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Due Date</Label>
              <Input id="due_date" type="date" value={formData.due_date || ""} onChange={(e) => setFormData({ ...formData, due_date: e.target.value })} className="font-medium border-slate-200 text-sm block w-full" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="estimated_hours" className="text-[10px] font-black uppercase tracking-wider text-slate-500">Est. Hours</Label>
              <Input id="estimated_hours" type="number" min="0" step="0.5" placeholder="e.g. 2.5" value={formData.estimated_hours || ""} onChange={(e) => setFormData({ ...formData, estimated_hours: e.target.value })} className="font-medium border-slate-200 text-sm" />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-end gap-2 pt-4 border-t border-slate-100 mt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto font-bold order-2 sm:order-1">Cancel</Button>
            <Button type="submit" disabled={isLoading} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md order-1 sm:order-2">
              {isLoading ? "Creating..." : "Create Task"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}