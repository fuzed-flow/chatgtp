import { initializeApp } from 'firebase/app';
import { getAuth, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCxQG7LStGWaLlIhBuXBzrWG-LTYAJB7ss",
  authDomain: "neat-bank-497520-t5.firebaseapp.com",
  projectId: "neat-bank-497520-t5",
  storageBucket: "neat-bank-497520-t5.firebasestorage.app",
  messagingSenderId: "166617929553",
  appId: "1:166617929553:web:b97756f10857498dace570",
  measurementId: "G-S4FJXQKDX5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

/**
 * HELPER: Waits for Firebase Auth to finish initializing 
 * so currentUser isn't null on an instant page refresh.
 */
const waitForAuth = () => {
  return new Promise((resolve) => {
    if (auth.currentUser) {
      resolve(auth.currentUser);
      return;
    }
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      unsubscribe();
      resolve(user);
    });
  });
};

// THE BRIDGE: Connects your old Base44 calls to real Firebase data
export const base44 = {
  auth: {
    me: async () => {
      // 1. Wait for Firebase to finish initializing and get the user
      const user = await waitForAuth();
      if (!user) {
        // Return an empty/guest structure instead of throwing a hard error
        // to prevent breaking layout renders entirely
        return null;
      }

      // 2. Fetch their role from the Firestore users list
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        const userData = userDoc.exists() ? userDoc.data() : { role: 'employee' };

        // 3. Return the exact format your layout expects
        return { 
          id: user.uid, 
          name: userData.name || userData.full_name || 'User', 
          email: user.email,
          role: userData.role || 'employee',
          user_role: userData.role || 'employee' // Added alternative mapping key just in case
        };
      } catch (e) {
        console.error("Error fetching user document:", e);
        return { id: user.uid, name: 'User', email: user.email, role: 'employee' };
      }
    },
    logout: async () => {
      await signOut(auth);
      window.location.href = '/login';
    },
    redirectToLogin: () => {
      window.location.href = '/login';
    }
  },
  entities: {},
  storage: {},
  functions: {}
};